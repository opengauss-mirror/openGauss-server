/*--------------------------------------------------------------------
 * Symbols referenced in this file:
 * - defWithOids
 *--------------------------------------------------------------------
 */

/* -------------------------------------------------------------------------
 *
 * define.cpp
 *	  Support routines for various kinds of object creation.
 *
 *
 * Portions Copyright (c) 2020 Huawei Technologies Co.,Ltd.
 * Portions Copyright (c) 1996-2012, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 * Portions Copyright (c) 2021, openGauss Contributors
 *
 *
 * IDENTIFICATION
 *	  src/gausskernel/optimizer/commands/define.cpp
 *
 * DESCRIPTION
 *	  The "DefineFoo" routines take the parse tree and pick out the
 *	  appropriate arguments/flags, passing the results to the
 *	  corresponding "FooDefine" routines (in src/catalog) that do
 *	  the actual catalog-munging.  These routines also verify permission
 *	  of the user to execute the command.
 *
 * NOTES
 *	  These things must be defined and committed in the following order:
 *		"create function":
 *				input/output, recv/send procedures
 *		"create type":
 *				type
 *		"create operator":
 *				operators
 *
 *
 * -------------------------------------------------------------------------
 */
#ifndef FRONTEND_PARSER
#include "postgres.h"
#include "knl/knl_variable.h"
#else
#include "postgres_fe.h"
#endif

#include <ctype.h>
#include <math.h>
#ifdef FRONTEND_PARSER
#include "nodes/parsenodes_common.h"
#include "commands/defrem.h"
#include "nodes/makefuncs.h"
#include "parser/scansup.h"
#else
#include "catalog/namespace.h"
#include "commands/defrem.h"
#include "nodes/makefuncs.h"
#include "parser/parse_type.h"
#include "parser/scansup.h"
#include "utils/int8.h"
#endif

#ifndef FRONTEND_PARSER


/*
 * Extract a string value (otherwise uninterpreted) from a DefElem.
 */


/*
 * Extract a numeric value (actually double) from a DefElem.
 */


/*
 * Extract a boolean value from a DefElem.
 */


/*
* Extract a boolean/int mixed value from a DefElem.(copy from fill_missing_fields)
*/


/*
 * Extract an int64 value from a DefElem.
 */


/*
 * Extract a possibly-qualified name (as a List of Strings) from a DefElem.
 */


/*
 * Extract a TypeName from a DefElem.
 *
 * Note: we do not accept a List arg here, because the parser will only
 * return a bare List when the name looks like an operator name.
 */


/*
 * Extract a type length indicator (either absolute bytes, or
 * -1 for "variable") from a DefElem.
 */


/*
 * Extract a list of string values (otherwise uninterpreted) from a DefElem.
 */


#endif /* !FRONTEND_PARSER */

/*
 * Create a DefElem setting "oids" to the specified value.
 */
DefElem* defWithOids(bool value)
{
    return makeDefElem("oids", (Node*)makeInteger(value));
}

/*
 * Set value with specific option, or add a new def value
 */
#ifndef FRONTEND_PARSER
#else
#endif 


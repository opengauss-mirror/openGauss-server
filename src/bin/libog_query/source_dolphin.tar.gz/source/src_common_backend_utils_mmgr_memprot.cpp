/*--------------------------------------------------------------------
 * Symbols referenced in this file:
 * - chunkSizeInBits
 * - SharedFunctions
 * - MemoryProtectFunctions::gs_memprot_malloc
 * - memTracker_ReserveMem
 * - shareTrackedBytes
 * - shareTrackedMemChunks
 * - eliminateErrorsMemoryBytes
 * - peakChunksSharedContext
 * - dynmicTrackedMemChunks
 * - memTracker_ReserveMemChunks
 * - backendUsedMemInChunk
 * - backendReservedMemInChunk
 * - processMemInChunks
 * - maxChunksPerProcess
 * - peakChunksPerProcess
 * - last_print_timestamp
 * - MemoryIsNotEnough
 * - memTracker_ReleaseMem
 * - memTracker_ReleaseMemChunks
 * - gs_memprot_failed
 * - MemoryProtectFunctions::gs_memprot_free
 * - MemoryProtectFunctions::gs_memprot_realloc
 * - MemoryProtectFunctions::gs_posix_memalign
 * - GenericFunctions
 * - SessionFunctions
 * - gs_memory_enjection
 *--------------------------------------------------------------------
 */

/*
 * Copyright (c) 2020 Huawei Technologies Co.,Ltd.
 *
 * openGauss is licensed under Mulan PSL v2.
 * You can use this software according to the terms and conditions of the Mulan PSL v2.
 * You may obtain a copy of Mulan PSL v2 at:
 *
 *          http://license.coscl.org.cn/MulanPSL2
 *
 * THIS SOFTWARE IS PROVIDED ON AN "AS IS" BASIS, WITHOUT WARRANTIES OF ANY KIND,
 * EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO NON-INFRINGEMENT,
 * MERCHANTABILITY OR FIT FOR A PARTICULAR PURPOSE.
 * See the Mulan PSL v2 for more details.
 * -------------------------------------------------------------------------
 *
 * memprot.cpp
 *
 * The implementation of memory protection. We implement a mechanism to enforce
 * a quota on the total memory consumption at query level.
 *
 * IDENTIFICATION
 *    src/common/backend/utils/mmgr/memprot.cpp
 *
 * -------------------------------------------------------------------------
 */

#include "postgres.h"
#include "knl/knl_variable.h"
#include "postmaster/postmaster.h"
#include "miscadmin.h"
#include "utils/aset.h"
#include "utils/atomic.h"
#include "utils/memprot.h"
#include "executor/exec/execStream.h"
#include "tcop/tcopprot.h"
#include "pgstat.h"
#include "pgxc/pgxc.h"
#include "libcomm/libcomm.h"
#include "replication/dataprotocol.h"
#include "replication/walprotocol.h"
#include "replication/walreceiver.h"
#include "replication/walsender.h"

/* Track memory usage by all shared memory context */
 volatile int32 shareTrackedMemChunks = 0;

 int64 shareTrackedBytes = 0;


/* Track memory usage in storage for it calls malloc directly */


/* peak size of shared memory context */
 int32 peakChunksSharedContext = 0;


/* Chunk size in bits. By default a chunk is 1MB. */
 unsigned int chunkSizeInBits = BITS_IN_MB;


/* Physical Memory quota of Machine In Memory */


/* Smoothing value to eliminate errors */
 int eliminateErrorsMemoryBytes = 1 * 1024 * 512;


 int32 maxChunksPerProcess = 0;
   // be set by GUC variable --max_dynamic_memory
 volatile int32 processMemInChunks = 200;
  // track the memory used by process --dynamic_used_memory
 int32 peakChunksPerProcess = 0;
  // the peak memory of process --dynamic_peak_memory
  // original comm memory
       // original shared memory
 int32 backendReservedMemInChunk = 0;
  // reserved memory for backend threads
 volatile int32 backendUsedMemInChunk = 0;
      // the memory usage for backend threads

/* Track memory usage by all dynamic memory context */
 volatile int32 dynmicTrackedMemChunks = 200;


/* THREAD LOCAL variable for print memory alarm string periodically */
 THR_LOCAL TimestampTz last_print_timestamp = 0;


/*
 * This is the virtual function table for Memory Functions
 */
 MemoryProtectFuncDef GenericFunctions = {MemoryProtectFunctions::gs_memprot_malloc<MEM_THRD>,
    MemoryProtectFunctions::gs_memprot_free<MEM_THRD>,
    MemoryProtectFunctions::gs_memprot_realloc<MEM_THRD>,
    MemoryProtectFunctions::gs_posix_memalign<MEM_THRD>};


 MemoryProtectFuncDef SessionFunctions = {MemoryProtectFunctions::gs_memprot_malloc<MEM_SESS>,
    MemoryProtectFunctions::gs_memprot_free<MEM_SESS>,
    MemoryProtectFunctions::gs_memprot_realloc<MEM_SESS>,
    MemoryProtectFunctions::gs_posix_memalign<MEM_SESS>};


 MemoryProtectFuncDef SharedFunctions = {MemoryProtectFunctions::gs_memprot_malloc<MEM_SHRD>,
    MemoryProtectFunctions::gs_memprot_free<MEM_SHRD>,
    MemoryProtectFunctions::gs_memprot_realloc<MEM_SHRD>,
    MemoryProtectFunctions::gs_posix_memalign<MEM_SHRD>};


extern uint64 g_searchserver_memory;
extern bool is_searchserver_api_load();
extern void* get_searchlet_resource_info(int* used_mem, int* peak_mem);

void gs_output_memory_info(void);

#ifdef MEMORY_CONTEXT_CHECKING
/*
 * inline function for memory enjection
 */
bool gs_memory_enjection(void)
{
    if (MEMORY_FAULT_PERCENT && !t_thrd.xact_cxt.bInAbortTransaction && !t_thrd.int_cxt.CritSectionCount &&
        !(AmPostmasterProcess()) && IsNormalProcessingMode() && t_thrd.utils_cxt.memNeedProtect &&
        (gs_random() % MAX_MEMORY_FAULT_PERCENT <= MEMORY_FAULT_PERCENT)) {
        return true;
    }

    return false;
}
#endif


/*
 * check if the node is on heavy memory status now?
 * is strict is true, we'll do some pre-judgement.
 */


/* check if system can service the new memory request */


/* find the information of abnormal memory context */
#ifndef ENABLE_MEMORY_CHECK
#else
#endif

/* recursive to verify the size of memory context and find the abnormal */


/* reset the beyond chunk for communication threads when memory allocation failed */


/* display the query string info */


/*
 * get the info from sessionMemoryEntry
 */


/* display the information of uncontrolled query in some user */


/* print the detail information when memory allocation is failed */
#ifdef ENABLE_MULTIPLE_NODES
#endif

/* the failure interface when allocating memory */
template <bool flag>
void gs_memprot_failed(int64 sz, MemType type)
{
    /* request 50 chunks (> 50M) for processing error */
    t_thrd.utils_cxt.beyondChunk += 50;

    uint64 debug_query_id = (u_sess == NULL) ? 0 : u_sess->debug_query_id;

    if (flag) {
        if (type == MEM_THRD)
            write_stderr(
                "----debug_query_id=%lu, memory allocation failed due to reaching the database memory limitation."
                " Current thread is consuming about %u MB, allocating %ld bytes.\n",
                debug_query_id,
                (uint32)t_thrd.utils_cxt.trackedMemChunks << (chunkSizeInBits - BITS_IN_MB),
                sz);
        else
            write_stderr(
                "----debug_query_id=%lu, memory allocation failed due to reaching the database memory limitation."
                " Current session is consuming about %u MB, allocating %ld bytes.\n",
                debug_query_id,
                (uint32)u_sess->stat_cxt.trackedMemChunks << (chunkSizeInBits - BITS_IN_MB),
                sz);
    } else {
        if (type == MEM_THRD)
            write_stderr(
                "----debug_query_id=%lu, FATAL: memory allocation failed due to reaching the OS memory limitation."
                " Current thread is consuming about %u MB, allocating %ld bytes.\n",
                debug_query_id,
                (uint32)t_thrd.utils_cxt.trackedMemChunks << (chunkSizeInBits - BITS_IN_MB),
                sz);
        else
            write_stderr(
                "----debug_query_id=%lu, FATAL: memory allocation failed due to reaching the OS memory limitation."
                " Current session is consuming about %u MB, allocating %ld bytes.\n",
                debug_query_id,
                (uint32)u_sess->stat_cxt.trackedMemChunks << (chunkSizeInBits - BITS_IN_MB),
                sz);
        write_stderr("----debug_query_id=%lu, Please check the sysctl configuration and GUC variable "
                     "g_instance.attr.attr_memory.max_process_memory.\n",
            debug_query_id);
    }
}

static bool MemoryIsNotEnough(int32 currentMem, int32 maxMem, bool needProtect)
{
    if (currentMem < maxMem) {
        return false;
    }

    /* this memory limit check already be mask off */
    if ((u_sess && u_sess->attr.attr_memory.disable_memory_protect) ||
        !t_thrd.utils_cxt.memNeedProtect || !needProtect) {
        return false;
    }

    /* this malloc could not be prevented */
    if ((t_thrd.int_cxt.CritSectionCount != 0) ||
        (AmPostmasterProcess()) || t_thrd.xact_cxt.bInAbortTransaction) {
        return false;
    }

    if (currentMem >= (maxMem + t_thrd.utils_cxt.beyondChunk)) {
        write_stderr("ERROR: memory alloc failed. Current role is: %d, maxMem is: %d, currMem is: %d.\n",
            t_thrd.role, maxMem, currentMem);
        return true;
    }

    return false;
}

/*
 * Reserve num of chunks for current thread. The reservation has to be
 * valid against query level memory quota.
 */
template <MemType type>
static bool memTracker_ReserveMemChunks(int32 numChunksToReserve, bool needProtect)
{
    int32 total = 0;
    volatile int32 *currSize = NULL;
    int32 *maxSize = NULL;

    Assert(0 < numChunksToReserve);

    /* increase chunk quota at global gaussdb process level */
    if (t_thrd.utils_cxt.backend_reserved) {
        currSize = &backendUsedMemInChunk;
        maxSize = &backendReservedMemInChunk;
    } else {
        currSize = &processMemInChunks;
        maxSize = &maxChunksPerProcess;
    }
    total = pg_atomic_add_fetch_u32((volatile uint32*)currSize, numChunksToReserve);

    /* Query memory quota is exhausted. Reset the counter then return false. */
    if (MemoryIsNotEnough(total, *maxSize, needProtect)) {
        (void)pg_atomic_sub_fetch_u32((volatile uint32*)currSize, numChunksToReserve);
        return false;
    }

    /* no longer to use the beyond chunk, so reset it */
    if (total < *maxSize) {
        t_thrd.utils_cxt.beyondChunk = 0;
    }

    /* query level memory verification */
    if (t_thrd.shemem_ptr_cxt.mySessionMemoryEntry && type != MEM_SHRD) {
        /* 1. increase memory in chunk at query level */
        total = gs_atomic_add_32(&(t_thrd.shemem_ptr_cxt.mySessionMemoryEntry->queryMemInChunks), numChunksToReserve);

        /* 2. update the peak memory of the query */
        if (t_thrd.shemem_ptr_cxt.mySessionMemoryEntry->peakChunksQuery < total)
            gs_lock_test_and_set(&(t_thrd.shemem_ptr_cxt.mySessionMemoryEntry->peakChunksQuery), total);
    }

    if (peakChunksPerProcess < processMemInChunks + backendUsedMemInChunk) {
        peakChunksPerProcess = processMemInChunks + backendUsedMemInChunk;

        /*Print memory alarm information every 1 minute.*/
        int threshold = PROCMEM_HIGHWATER_THRESHOLD >> (chunkSizeInBits - BITS_IN_MB);
        if ((backendUsedMemInChunk + processMemInChunks) >
            (backendReservedMemInChunk + maxChunksPerProcess + threshold)) {
            TimestampTz current = GetCurrentTimestamp();
            if (u_sess != NULL && TimestampDifferenceExceeds(last_print_timestamp, current, 60000)) {
                uint32 processMemMB =
                    (uint32)(backendUsedMemInChunk + processMemInChunks) << (chunkSizeInBits - BITS_IN_MB);
                uint32 reserveMemMB = (uint32)numChunksToReserve << (chunkSizeInBits - BITS_IN_MB);
                write_stderr("WARNING: process memory allocation %u MB, pid %lu, "
                             "thread self memory %ld bytes, new %ld bytes allocated, statement(%s).\n",
                    processMemMB, t_thrd.proc_cxt.MyProcPid, t_thrd.utils_cxt.trackedBytes, (int64)reserveMemMB << BITS_IN_MB,
                    (t_thrd.postgres_cxt.debug_query_string != NULL) ? t_thrd.postgres_cxt.debug_query_string : "NULL");

                last_print_timestamp = current;
            }
        }
    }

    return true;
}

/*
 * Reserve requestedBytes from the memory tracking system.
 *
 * We use BITS_IN_MB sized chunk as the unit to reserve the
 * memory for newly requested bytes for performance reason.
 * If the newly requested bytes can fit into the previous
 * reserved chunk, it does not reserve a new chunk.
 */
template <MemType type>
bool memTracker_ReserveMem(int64 requestedBytes, bool needProtect)
{
    bool status = true;
    int64 tb = 0;
    int32 tc = 0;
    int32 needChunk = 0;

    if (type == MEM_SHRD) {
        tc = (uint64)shareTrackedBytes >> chunkSizeInBits;
        tb = gs_atomic_add_64(&shareTrackedBytes, requestedBytes);
        gs_lock_test_and_set(&shareTrackedMemChunks, tc); /* reset the value */
    } else if (type == MEM_THRD) {
        tc = t_thrd.utils_cxt.trackedMemChunks;
        t_thrd.utils_cxt.trackedBytes += requestedBytes;
        tb = t_thrd.utils_cxt.trackedBytes;
    } else {
        tc = u_sess->stat_cxt.trackedMemChunks;
        u_sess->stat_cxt.trackedBytes += requestedBytes;
        tb = u_sess->stat_cxt.trackedBytes;
    }

    // How many chunks we need so far
    if (type != MEM_SHRD) {
        tb = tb + eliminateErrorsMemoryBytes;
    }
    int32 newszChunk = (uint64)tb >> chunkSizeInBits;

    if (newszChunk > tc) {
        needChunk = newszChunk - tc;

        status = memTracker_ReserveMemChunks<type>(needChunk, needProtect);
    }

    if (status == false) {
        if (type == MEM_SHRD)
            gs_atomic_add_64(&shareTrackedBytes, -requestedBytes);
        else if (type == MEM_THRD)
            t_thrd.utils_cxt.trackedBytes -= requestedBytes;
        else
            u_sess->stat_cxt.trackedBytes -= requestedBytes;
    } else {
        if (type == MEM_SHRD) {
            (void)pg_atomic_add_fetch_u32((volatile uint32*)&shareTrackedMemChunks, needChunk);
            if (shareTrackedMemChunks > peakChunksSharedContext)
                peakChunksSharedContext = shareTrackedMemChunks;
        } else {
            if (type == MEM_THRD)
                t_thrd.utils_cxt.trackedMemChunks = newszChunk;
            else
                u_sess->stat_cxt.trackedMemChunks = newszChunk;
            if (needChunk != 0) {
                (void)pg_atomic_add_fetch_u32((volatile uint32*)&dynmicTrackedMemChunks, needChunk);
            }

            t_thrd.utils_cxt.basedBytesInQueryLifeCycle += requestedBytes;
            if(t_thrd.utils_cxt.basedBytesInQueryLifeCycle > t_thrd.utils_cxt.peakedBytesInQueryLifeCycle)
                t_thrd.utils_cxt.peakedBytesInQueryLifeCycle = t_thrd.utils_cxt.basedBytesInQueryLifeCycle;
        }
    }

    return status;
}

/*
 * Releases "reduction" number of chunks to the query.
 */
template <MemType type>
static void memTracker_ReleaseMemChunks(int reduction)
{
    int total = 0;
    Assert(0 <= reduction);

    /* reduce chunk quota at global gaussdb process level */
    if (t_thrd.utils_cxt.backend_reserved) {
        total = pg_atomic_sub_fetch_u32((volatile uint32*)&backendUsedMemInChunk, reduction);
    } else {
        total = pg_atomic_sub_fetch_u32((volatile uint32*)&processMemInChunks, reduction);
    }

    if (t_thrd.shemem_ptr_cxt.mySessionMemoryEntry && type != MEM_SHRD) {
        total = gs_atomic_add_32(&(t_thrd.shemem_ptr_cxt.mySessionMemoryEntry->queryMemInChunks), -reduction);
    }
}

/*
 * Releases requested size bytes memory.
 *
 * For performance reason this method accumulates free requests until it has
 * enough bytes to free a whole chunk.
 */
template <MemType type>
void memTracker_ReleaseMem(int64 toBeFreedRequested)
{
    int32 tc = 0;
    int64 tb = 0;

    /*
     * We need this adjustment as gaussdb may request to free more memory than it reserved, apparently
     * because a bug somewhere that tries to release memory for allocations made before the memory
     * tracking system was initialized.
     */
    if (type == MEM_SHRD)
        tb = shareTrackedBytes;
    else if (type == MEM_THRD)
        tb = t_thrd.utils_cxt.trackedBytes;
    else
        tb = u_sess->stat_cxt.trackedBytes;

    int64 toBeFreed = Min(tb, toBeFreedRequested);
    if (0 == toBeFreed) {
        return;
    }

    if (type == MEM_SHRD) {
        tc = (uint64)shareTrackedBytes >> chunkSizeInBits;
        tb = gs_atomic_add_64(&shareTrackedBytes, -toBeFreed);
        gs_lock_test_and_set(&shareTrackedMemChunks, tc); /* reset the value */
    } else if (type == MEM_THRD) {
        tc = t_thrd.utils_cxt.trackedMemChunks;
        t_thrd.utils_cxt.trackedBytes -= toBeFreed;
        t_thrd.utils_cxt.basedBytesInQueryLifeCycle -= toBeFreed;
        tb = t_thrd.utils_cxt.trackedBytes;
    } else {
        tc = u_sess->stat_cxt.trackedMemChunks;
        u_sess->stat_cxt.trackedBytes -= toBeFreed;
        tb = u_sess->stat_cxt.trackedBytes;
        t_thrd.utils_cxt.basedBytesInQueryLifeCycle -= toBeFreed;
    }

    if (type != MEM_SHRD) {
        tb = tb + eliminateErrorsMemoryBytes;
    }
    int newszChunk = (uint64)tb >> chunkSizeInBits;

    if (newszChunk < tc) {
        int reduction = tc - newszChunk;

        memTracker_ReleaseMemChunks<type>(reduction);

        if (type == MEM_SHRD)
            (void)pg_atomic_sub_fetch_u32((volatile uint32*)&shareTrackedMemChunks, reduction);
        else {
            if (type == MEM_THRD)
                t_thrd.utils_cxt.trackedMemChunks = newszChunk;
            else
                u_sess->stat_cxt.trackedMemChunks = newszChunk;
            (void)pg_atomic_sub_fetch_u32((volatile uint32*)&dynmicTrackedMemChunks, reduction);
        }

        /* reset the total value if not matching */
        int total = shareTrackedMemChunks + dynmicTrackedMemChunks;
        gs_lock_test_and_set(&processMemInChunks, total);
    }
}

// Return current memory usage in MB for query
//


/*
 * Memory allocation for sz bytes. If memory quota is enabled, it uses gs_malloc_internal to
 * reserve the chunk and allocate memory.
 */
template <MemType mem_type>
void* MemoryProtectFunctions::gs_memprot_malloc(Size sz, bool needProtect)
{
    if (!t_thrd.utils_cxt.gs_mp_inited)
        return malloc(sz);

    void* ptr = NULL;
    bool status = memTracker_ReserveMem<mem_type>(sz, needProtect);

    if (status == true) {
        ptr = malloc(sz);
        if (ptr == NULL) {
            memTracker_ReleaseMem<mem_type>(sz);
            gs_memprot_failed<false>(sz, mem_type);

            return NULL;
        }

        return ptr;
    }

    gs_memprot_failed<true>(sz, mem_type);

    return NULL;
}

template <MemType mem_type>
void MemoryProtectFunctions::gs_memprot_free(void* ptr, Size sz)
{
    free(ptr);
    ptr = NULL;

    if (t_thrd.utils_cxt.gs_mp_inited)
        memTracker_ReleaseMem<mem_type>(sz);
}

/* Reallocates memory, respecting memory quota, if enabled */
template <MemType mem_type>
void* MemoryProtectFunctions::gs_memprot_realloc(void* ptr, Size sz, Size newsz, bool needProtect)
{
    Assert(GS_MP_INITED);  // Must be used when memory protect feature is available

    void* ret = NULL;

    if ((newsz > 0) && memTracker_ReserveMem<mem_type>(newsz, needProtect)) {
        memTracker_ReleaseMem<mem_type>(sz);
        ret = realloc(ptr, newsz);
        if (ret == NULL) {
            memTracker_ReleaseMem<mem_type>(newsz);

            gs_memprot_failed<false>(newsz, mem_type);

            return NULL;
        }

        return ret;
    }

    gs_memprot_failed<true>(newsz, mem_type);
    return NULL;
}

/* posix_memalign interface */
template <MemType mem_type>
int MemoryProtectFunctions::gs_posix_memalign(void** memptr, Size alignment, Size sz, bool needProtect)
{
    if (!t_thrd.utils_cxt.gs_mp_inited)
        return posix_memalign(memptr, alignment, sz);

    int ret = 0;
    bool status = memTracker_ReserveMem<mem_type>(sz, needProtect);

    if (status == true) {
        ret = posix_memalign(memptr, alignment, sz);
        if (ret) {
            memTracker_ReleaseMem<mem_type>(sz);
            gs_memprot_failed<false>(sz, mem_type);

            return ret;
        }

        return ret;
    }

    gs_memprot_failed<true>(sz, mem_type);

    return ENOMEM; /* insufficient memory */
}

/**
 * reseve memory for mmap of compressed table
 * @tparam mem_type MEM_SHRD is supported only
 * @param sz reserved size(bytes)
 * @param needProtect
 * @return success or not
 */


/**
 * release the momery allocated by gs_memprot_reserve
 * @tparam type MEM_SHRD is supported only
 * @param sz free size(bytes)
 */


/* thread level initialization */




/* process level initialization only called in postmaster main thread */
#ifdef ENABLE_MULTIPLE_NODES
#else
#endif
#ifdef ENABLE_HTAP
#endif
#ifdef ENABLE_HTAP
#else
#endif

/* Recompute how many memory remain except used by simsearch. */


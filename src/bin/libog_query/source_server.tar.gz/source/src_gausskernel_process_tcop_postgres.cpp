/*--------------------------------------------------------------------
 * Symbols referenced in this file:
 * - checkCompArgs
 * - check_stack_depth
 * - stack_is_too_deep
 *--------------------------------------------------------------------
 */

/* -------------------------------------------------------------------------
 *
 * postgres.cpp
 *	  POSTGRES C Backend Interface
 *
 * Portions Copyright (c) 2020 Huawei Technologies Co.,Ltd.
 * Portions Copyright (c) 1996-2012, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 * Portions Copyright (c) 2010-2012 Postgres-XC Development Group
 * Portions Copyright (c) 2021, openGauss Contributors
 *
 * IDENTIFICATION
 *	  src/gausskernel/process/tcop/postgres.cpp
 *
 * NOTES
 *	  this is the "main" module of the postgres backend and
 *	  hence the main module of the "traffic cop".
 *
 * -------------------------------------------------------------------------
 */
#include "postgres.h"
#include "knl/knl_variable.h"
#include "catalog/pg_user_status.h"

#include <fcntl.h>
#include <limits.h>

#ifdef HAVE_SYS_RESOURCE_H
#include <sys/time.h>
#include <sys/resource.h>
#endif

#ifndef HAVE_GETRUSAGE
#include "rusagestub.h"
#endif

#ifdef HAVE_POLL_H
#include <poll.h>
#endif

#include "access/printtup.h"
#include "access/xact.h"
#include "access/xlogdefs.h"
#include "access/ustore/undo/knl_uundoapi.h"
#include "access/double_write.h"
#include "catalog/namespace.h"
#include "catalog/pg_authid.h"
#include "catalog/pg_database.h"
#include "catalog/pg_proc.h"
#include "catalog/pg_type.h"
#include "catalog/pg_extension.h"
#include "commands/async.h"
#include "commands/extension.h"
#include "commands/matview.h"
#include "commands/prepare.h"
#include "commands/user.h"
#include "commands/vacuum.h"
#include "commands/auto_parameterization.h"
#ifdef PGXC
#include "commands/trigger.h"
#endif
#include "executor/spi.h"
#include "executor/node/nodeRecursiveunion.h"
#include "libpq/libpq.h"
#include "libpq/pqformat.h"
#include "libpq/pqsignal.h"
#include "libpq/crypt.h"
#include "miscadmin.h"
#include "nodes/print.h"
#include "optimizer/planner.h"
#include "optimizer/bucketpruning.h"
#include "pgstat.h"
#include "pg_trace.h"
#include "parser/analyze.h"
#include "parser/parse_hint.h"
#include "parser/parser.h"
#include "parser/parse_coerce.h"
#ifdef PGXC
#include "parser/parse_type.h"
#endif /* PGXC */
#include "postmaster/autovacuum.h"
#include "postmaster/postmaster.h"
#include "postmaster/snapcapturer.h"
#include "postmaster/cfs_shrinker.h"
#include "replication/logicallauncher.h"
#include "replication/logicalworker.h"
#include "replication/dataqueue.h"
#include "replication/datasender.h"
#include "replication/walsender.h"
#include "replication/slot.h"
#include "replication/syncrep.h"
#include "rewrite/rewriteHandler.h"
#include "storage/buf/bufmgr.h"
#include "storage/ipc.h"
#include "storage/lmgr.h"
#include "storage/proc.h"
#include "storage/procsignal.h"
#include "storage/xlog_share_storage/xlog_share_storage.h"
#include "storage/sinval.h"
#include "tcop/fastpath.h"
#include "tcop/pquery.h"
#include "tcop/tcopprot.h"
#include "tcop/utility.h"
#include "utils/be_module.h"
#include "utils/hotkey.h"
#include "utils/inval.h"
#include "utils/lsyscache.h"
#include "utils/memutils.h"
#include "utils/postinit.h"
#include "utils/ps_status.h"
#include "utils/plog.h"
#include "utils/selfuncs.h"
#include "utils/snapmgr.h"
#include "utils/timestamp.h"
#include "utils/fmgroids.h"
#include "mb/pg_wchar.h"
#include "pgaudit.h"
#include "auditfuncs.h"
#include "funcapi.h"
#ifdef PGXC
#include "distributelayer/streamMain.h"
#include "pgxc/groupmgr.h"
#include "pgxc/pgxc.h"
#include "access/gtm.h"
/* PGXC_COORD */
#include "pgxc/execRemote.h"
#include "pgxc/barrier.h"
#include "optimizer/pgxcplan.h"
#include "nodes/nodes.h"
#include "pgxc/poolmgr.h"
#include "pgxc/poolutils.h"
#include "pgxc/pgxcnode.h"
#include "pgxc/locator.h"
#include "commands/copy.h"
#include "commands/matview.h"
#include "workload/cpwlm.h"
#include "workload/workload.h"
/* PGXC_DATANODE */
#include "access/transam.h"
#include "catalog/namespace.h"
#endif
#include "gssignal/gs_signal.h"
#include "optimizer/streamplan.h"
#include "optimizer/randomplan.h"
#ifdef HAVE_INT_OPTRESET
extern int optreset; /* might not be declared by system headers */
#endif
#include "access/xact.h"
#include "catalog/pgxc_node.h"
#include "executor/exec/execStream.h"
#include "executor/lightProxy.h"
#include "executor/node/nodeIndexscan.h"
#include "executor/node/nodeModifyTable.h"
#include "gstrace/gstrace_infra.h"
#include "gstrace/tcop_gstrace.h"

#include "instruments/instr_unique_sql.h"
#include "instruments/snapshot.h"
#include "instruments/instr_slow_query.h"
#include "instruments/unique_query.h"
#include "instruments/instr_handle_mgr.h"
#include "instruments/instr_statement.h"
#include "nodes/parsenodes.h"
#include "opfusion/opfusion.h"
#include "parser/parser.h"
#include "parser/parsetree.h"
#include "pgxc/route.h"
#include "tcop/stmt_retry.h"
#include "threadpool/threadpool.h"
#ifdef ENABLE_MULTIPLE_NODES
#include "pgxc/pgFdwRemote.h"
#include "tsdb/utils/ts_redis.h"
#endif
#include "utils/acl.h"
#include "utils/distribute_test.h"
#include "utils/elog.h"
#include "utils/guc_storage.h"
#include "utils/guc_tables.h"
#include "utils/memprot.h"
#include "utils/memtrack.h"
#include "utils/plpgsql.h"
#include "utils/syscache.h"
#include "access/heapam.h"
#include "utils/plancache.h"
#include "commands/tablecmds.h"
#include "catalog/gs_matview.h"
#include "streaming/dictcache.h"
#include "parser/parse_target.h"
#include "streaming/streaming_catalog.h"
#include "postmaster/bgworker.h"
#ifdef ENABLE_MOT
#include "storage/mot/jit_exec.h"
#endif
#include "commands/sqladvisor.h"
#include "storage/file/fio_device.h"
#include "storage/dss/dss_adaptor.h"
#include "storage/dss/dss_log.h"
#include "replication/libpqsw.h"
#include "replication/walreceiver.h"
#include "libpq/libpq-int.h"
#include "tcop/autonomoustransaction.h"
#ifdef ENABLE_HTAP
#include "access/htap/imcs_ctlg.h"
#endif





#define GSCGROUP_ATTACH_TASK()                                                                                   \
    {                                                                                                            \
        if (u_sess->attr.attr_resource.use_workload_manager && g_instance.wlm_cxt->gscgroup_init_done &&         \
            !IsAbortedTransactionBlockState() && u_sess->wlm_cxt->cgroup_state == CG_USERSET &&                  \
            CGroupIsValid(u_sess->wlm_cxt->control_group) && !CGroupIsDefault(u_sess->wlm_cxt->control_group)) { \
            gscgroup_attach_task(t_thrd.wlm_cxt.thread_node_group, u_sess->wlm_cxt->control_group);              \
        }                                                                                                        \
    }

#define IS_CLIENT_CONN_VALID(port) \
    (((port) == NULL)              \
            ? false                \
            : (((port)->is_logic_conn) ? ((port)->gs_sock.type != GSOCK_INVALID) : ((port)->sock != NO_SOCKET)))

typedef struct AttachInfoContext {
    char* info_query_string;
    Node* info_node;
    int info_index;
} AttachInfoContext;

#define PARAMS_LEN 4096
#define PRINFT_DST_MAX_DOUBLE 64
#define MEMCPY_DST_NUM 4

#define MAXSTRLEN ((1 << 11) - 1)

extern PgBackendStatus* GetMyBEEntry(void);
extern THR_LOCAL bool g_pq_interrupt_happened;

/*
 * global node definition, process-wise global variable, mainly for debug purpose
 * when using view pgxc_thread_wait_status. It will be updated only if cluster size
 * changes.
 */






/*
 * On IA64 we also have to remember the register stack base.
 */
#if defined(__ia64__) || defined(__ia64)
char* register_stack_base_ptr = NULL;
#endif

extern THR_LOCAL DistInsertSelectState* distInsertSelectState;

extern void InitQueryHashTable(void);
/*
 * @hdfs
 * Define different mesage type used for exec_simple_query
 */
typedef enum { QUERY_MESSAGE = 0, HYBRID_MESSAGE } MessageType;

/* For shared storage mode */
typedef enum {
    XLOG_COPY_NOT = 0,
    XLOG_COPY_FROM_LOCAL,
    XLOG_FORCE_COPY_FROM_LOCAL,
    XLOG_COPY_FROM_SHARE
} XLogCopyMode;



/* ----------------------------------------------------------------
 *		decls for routines only used in this file
 * ----------------------------------------------------------------
 */
static int InteractiveBackend(StringInfo inBuf);
static int interactive_getc(void);
static int ReadCommand(StringInfo inBuf);
bool check_log_statement(List* stmt_list);
static int errdetail_execute(List* raw_parsetree_list);
int errdetail_params(ParamListInfo params);
static List* pg_rewrite_query(Query* query);
static int errdetail_recovery_conflict(void);
bool IsTransactionExitStmt(Node* parsetree);
static bool IsTransactionExitStmtList(List* parseTrees);
static bool IsTransactionStmtList(List* parseTrees);
#ifdef ENABLE_MOT
static bool IsTransactionPrepareStmt(const Node* parsetree);
#endif
static void drop_unnamed_stmt(void);
static void SigHupHandler(SIGNAL_ARGS);
static void ForceModifyInitialPwd(const char* query_string, List* parsetree_list);
static void ForceModifyExpiredPwd(const char* queryString, const List* parsetreeList);
#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
static void InitGlobalNodeDefinition(PlannedStmt* planstmt);
extern void SetRemoteDestTupleReceiverParams(DestReceiver *self);
#endif
static int getSingleNodeIdx_internal(ExecNodes* exec_nodes, ParamListInfo params);
extern void CancelAutoAnalyze();




extern void CodeGenThreadInitialize();

extern CmdType set_cmd_type(const char* commandTag);
static void exec_batch_bind_execute(StringInfo input_message);

/*
 * MPP with recursive support
 */


#ifdef ENABLE_MULTIPLE_NODES
/* ----------------------------------------------------------------
 *		PG-XC routines
 * ----------------------------------------------------------------
 */

/*
 * Called when the backend is ending.
 */
static void DataNodeShutdown(int code, Datum arg)
{
    /* Close connection with GTM, if active */
    CloseGTM();

    /* Free remote xact state */
    free_RemoteXactState();
    /* Free gxip */
    UnsetGlobalSnapshotData();
}

/*
 * Check if the SIGUSR2 is trying to cancel GTM connection.
 */
static bool SignalCancelGTMConnection()
{
    if (t_thrd.proc != NULL) {
        uint32 gtmhost_flag = pg_atomic_fetch_add_u32(&t_thrd.proc->signal_cancel_gtm_conn_flag, 0);
        (void)pg_atomic_exchange_u32(&t_thrd.proc->signal_cancel_gtm_conn_flag, 0);
        if (gtmhost_flag > 0) {
            SetGTMInterruptFlag();
            t_thrd.proc->suggested_gtmhost = FLAG2HOST(gtmhost_flag);
            return true;
        }
    }

    return false;
}

#endif

/* ----------------------------------------------------------------
 *		routines to obtain user input
 * ----------------------------------------------------------------
 */
/* ----------------
 *	InteractiveBackend() is called for user interactive connections
 *
 *	the string entered by the user is placed in its parameter inBuf,
 *	and we act like a Q message was received.
 *
 *	EOF is returned if end-of-file input is seen; time to shut down.
 * ----------------
 */



/*
 * interactive_getc -- collect one character from stdin
 *
 * Even though we are not reading from a "client" process, we still want to
 * respond to signals, particularly SIGTERM/SIGQUIT.
 */


/* ----------------
 *	SocketBackend()		Is called for frontend-backend connections
 *
 *	Returns the message type code, and loads message body data into inBuf.
 *
 *	EOF is returned if the connection is lost.
 * ----------------
 */
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES      
#else
#endif
#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)         /* PGXC_DATANODE */
#endif

/* if online sqladvsior collect workload is running, check query->rtable */


/*
 * Check replication uuid options for wal senders.
 * Return false if gucName is not repl_uuid.
 */




/* ----------------
 *		ReadCommand reads a command from either the frontend or
 *		standard input, places it in inBuf, and returns the
 *		message type code (first byte of the message).
 *		EOF is returned if end of file.
 * ----------------
 */
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif

/*
 * process_client_read_interrupt- Process interrupts specific to client reads
 *
 * interrupted by 2 ways:
 * 1. read finished
 * 2. interrupt by user
 *
 * Must preserve errno!
 */


/*
 * process_client_write_interrupt - Process interrupts specific to client writes
 *
 * interrupted by 2 ways:
 * 1. write finished
 * 2. interrupt by user
 * 'blocked' tells whether the socket is in blocked mode
 *
 * Must preserve errno!
 */



/*
 * prepare_for_client_read -- set up to possibly block on client input
 *
 * This must be called immediately before any low-level read from the
 * client connection.  It is necessary to do it at a sufficiently low level
 * that there won't be any other operations except the read kernel call
 * itself between this call and the subsequent client_read_ended() call.
 * In particular there mustn't be use of malloc() or other potentially
 * non-reentrant libc functions.  This restriction makes it safe for us
 * to allow interrupt service routines to execute nontrivial code while
 * we are waiting for input.
 */


/*
 * prepare_for_logic_conn_read
 */


/*
 * logic_conn_read_ended
 */


/*
 * client_read_ended -- get out of the client-input state
 */


#if (!defined(ENABLE_MULTIPLE_NODES)) && (!defined(ENABLE_PRIVATEGAUSS))





#define INIT_PLUGIN_OBJECT "init_plugin_object"
#define WHALE "whale"
#define DOLPHIN "dolphin"




#define LOAD_DOLPHIN "create_dolphin_extension"


#define INIT_DOLPHIN_PROTO "init_dolphin_proto"
typedef void (*init_dolphin_proto_fn)(char *database_name);


#endif

/*
 * Do raw parsing (only).
 *
 * A list of parsetrees is returned, since there might be multiple
 * commands in the given string.
 *
 * NOTE: for interactive queries, it is important to keep this routine
 * separate from the analysis & rewrite stages.  Analysis and rewriting
 * cannot be done in an aborted transaction, since they require access to
 * database tables.  So, we rely on the raw parser to determine whether
 * we've seen a COMMIT or ABORT command; when we are in abort state, other
 * commands are not processed any further than the raw parse stage.
 */
#if (!defined(ENABLE_MULTIPLE_NODES)) && (!defined(ENABLE_PRIVATEGAUSS))
#endif
#ifdef COPY_PARSE_PLAN_TREES
#endif

/*
 * Given a raw parsetree (gram.y output), and optionally information about
 * types of parameter symbols ($n), perform parse analysis and rule rewriting.
 *
 * A list of Query nodes is returned, since either the analyzer or the
 * rewriter might expand one query to several.
 *
 * NOTE: for reasons mentioned above, this must be separate from raw parsing.
 */
List* pg_analyze_and_rewrite(Node* parsetree, const char* query_string, Oid* paramTypes, int numParams, ParseState* parent_pstate) {return nullptr;}


/*
 * Do parse analysis and rewriting.  This is the same as pg_analyze_and_rewrite
 * except that external-parameter resolution is determined by parser callback
 * hooks instead of a fixed list of parameter datatypes.
 */
#ifdef PGXC
#endif

/*
 * Perform rewriting of a query produced by parse analysis.
 *
 * Note: query must just have come from the parser, because we do not do
 * AcquireRewriteLocks() on it.
 */
#ifdef ENABLE_MULTIPLE_NODES
#else
#endif
#ifdef COPY_PARSE_PLAN_TREES
#endif

/*
 * check compute privilieges for expected_computing_modegroup .
 */


/*
 * Generate a plan for a single already-rewritten query.
 * This is a thin wrapper around planner() and takes the same parameters.
 */
#ifdef COPY_PARSE_PLAN_TREES
#ifdef NOT_USED
#endif
#endif

/*
 * Check whether the query is insert multiple values query.
 * In the insert query, only one RTE_VALUES in the ratble is a multi-values query..
 */



/*
 * Generate plans for a list of already-rewritten queries.
 *
 * Normal optimizable statements generate PlannedStmt entries in the result
 * list.  Utility statements are simply represented by their statement nodes.
 */
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif

/* Get the tag automatically for plan shipping.
 * For now plan shipping is used only for SELECT\INSERT\DELETE\UPDATA\MERGE.
 */


#ifdef USE_SPQ
void ChangeDMLPlanForRONode(PlannedStmt* plan)
{
    if (IS_SPQ_EXECUTOR && !SS_PRIMARY_MODE &&
        (plan->commandType == CMD_INSERT || plan->commandType == CMD_UPDATE || plan->commandType == CMD_DELETE)) {
        if (IsA(plan->planTree, ModifyTable)) {
            ModifyTable* node = (ModifyTable*)plan->planTree;
            ListCell* l = NULL;
            foreach (l, node->plans) {
                plan->planTree = (Plan*)lfirst(l);
            }
        }
        ListCell *rtcell;
        RangeTblEntry *rte;
        AclMode removeperms = ACL_INSERT | ACL_UPDATE | ACL_DELETE | ACL_SELECT_FOR_UPDATE;

        /* Just reading, so don't check INS/DEL/UPD permissions. */
        foreach(rtcell, plan->rtable) {
            rte = (RangeTblEntry *)lfirst(rtcell);
            if (rte->rtekind == RTE_RELATION &&
                0 != (rte->requiredPerms & removeperms))
                rte->requiredPerms &= ~removeperms;
        }
    }
}
#endif
/*
 * exec_simple_plan
 *
 * Execute a "simple Plan" received from coordinator
 */
#ifdef USE_SPQ
#endif

/*
 * @hdfs
 * spilt_querystring_sql_info
 *
 * when we got a hybirdmesage. We call this function to split query_string into two parts.
 * Sql_query_string and info_query_string, both of them will be set value in this function.
 * For example if we got a hybridmessage like "analyze table_name;information......" storing
 * in query_string, sql_query_string and info_query_string are set into "analyze table_name;"
 * and "information......", separately.
 */


/*
 * @hdfs
 * attach_info_to_plantree_list
 *
 * If we got a hybridmessage, the second part of the messaget is information string.
 * We use this function transfer information string to a struct whose type is related to
 * query string type. The struct will be add to plantree_list.
 */
#define READ_MEM_USAGE(type)                                                                                  \
    do {                                                                                                      \
        type* indexStmt = (type*)stmt;                                                                        \
        List* mem_list = (List*)stringToNode(info_query_string);                                              \
        if (unlikely(list_length(mem_list) != 2))                                                             \
            ereport(ERROR,                                                                                    \
                    (errmsg("unexpect list length %d of mem_list from info_query_string.",                    \
                     mem_list->length)));                                                                      \
        indexStmt->memUsage.work_mem = list_nth_int(mem_list, 0);                                             \
        indexStmt->memUsage.max_mem = list_nth_int(mem_list, 1);                                              \
        list_free(mem_list);                                                                                  \
        MEMCTL_LOG(DEBUG3, "DN receive (%d, %d)", indexStmt->memUsage.work_mem, indexStmt->memUsage.max_mem); \
    } while (0)
#ifdef ENABLE_MOT
#else
#endif

#ifdef ENABLE_MULTIPLE_NODES
#endif



/*
 * exec_simple_query
 *
 * Execute a "simple Query" protocol message.
 *
 * @hdfs
 * Add default parameter unint16 messageType. Its default vaule is 0. If we receive
 * hybridmesage, this parameter will be set to 1 to tell us the normal query string
 * followed by information string. query_string = normal querystring + message.
 */
#ifdef ENABLE_DISTRIBUTE_TEST
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MOT
#endif
#ifdef PGXC
#endif

#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
/*
 * exec_plan_with_params
 *
 * Execute a "extend plan with params" received from coordinator
 */
static void exec_plan_with_params(StringInfo input_message)
{
    CommandDest dest = (CommandDest)t_thrd.postgres_cxt.whereToSendOutput;
    bool save_log_statement_stats = u_sess->attr.attr_common.log_statement_stats;

    PlannedStmt* planstmt = NULL;
    Node* node = NULL;

    int numParams;
    Oid* paramTypes = NULL;
    char** paramTypeNames = NULL;

    int numPFormats;
    int16* pformats = NULL;
    int numRFormats;
    int16* rformats = NULL;

    ParamListInfo params;
    long max_rows;

    if (save_log_statement_stats)
        ResetUsage();

    /* "IS_PGXC_DATANODE && StreamTopConsumerAmI()" means on the CN of the compute pool. */
    if (IS_PGXC_COORDINATOR && StreamTopConsumerAmI())
        exec_init_poolhandles();

    start_xact_command();

    /* Switch back to message context */
    MemoryContext oldcontext = MemoryContextSwitchTo(t_thrd.mem_cxt.msg_mem_cxt);

    /* get plan */
    const char* plan_string = pq_getmsgstring(input_message);
    if (strlen(plan_string) > SECUREC_MEM_MAX_LEN) {
        ereport(ERROR, (errcode(ERRCODE_FEATURE_NOT_SUPPORTED),
                        errmsg("Too long plan_string.")));
    }
    node = (Node*)stringToNode((char*)plan_string);
    if (node != NULL && !IsA(node, PlannedStmt)) {
        ereport(ERROR, (errcode(ERRCODE_UNEXPECTED_NODE_STATE), errmsg("Received unexpected node type.")));
    }

    planstmt = (PlannedStmt*) node;

    InitGlobalNodeDefinition(planstmt);

    if (planstmt == NULL) {
        ereport(ERROR, (errcode(ERRCODE_UNEXPECTED_NULL_VALUE), errmsg("Invaild parameter.")));
    }

    ChangeDMLPlanForRONode(planstmt);

    if (ThreadIsDummy(planstmt->planTree)) {
        u_sess->stream_cxt.dummy_thread = true;
        u_sess->exec_cxt.executorStopFlag = true;
    }

    /* nodeid in planstmt->planTree->exec_nodes->nodeList is from DWS,
     * and PGXCNodeId is from the compute pool. so ignore the result of ThreadIsDummy()
     * and set u_sess->exec_cxt.executor_stop_flag and u_sess->stream_cxt.dummy_thread to proper value.
     */
    if (planstmt->in_compute_pool) {
        u_sess->stream_cxt.dummy_thread = false;
        u_sess->exec_cxt.executorStopFlag = false;
    }

    /* get parameter numbers */
    numParams = pq_getmsgint(input_message, 2);

    /* get parameter types */
    paramTypes = (Oid*)palloc(numParams * sizeof(Oid));
    if (numParams > 0) {
        int i;
        paramTypeNames = (char**)palloc(numParams * sizeof(char*));
        for (i = 0; i < numParams; i++)
            paramTypeNames[i] = (char*)pq_getmsgstring(input_message);
    }

    if (paramTypeNames != NULL) {
        if (IS_SPQ_EXECUTOR || IsConnFromCoord() || (IS_PGXC_COORDINATOR && planstmt->in_compute_pool)) {
            int cnt_param;
            for (cnt_param = 0; cnt_param < numParams; cnt_param++)
                parseTypeString(paramTypeNames[cnt_param], &paramTypes[cnt_param], NULL);
        }
    }

    /* Get the parameter format codes */
    numPFormats = pq_getmsgint(input_message, 2);
    if (numPFormats > 0) {
        int i;

        pformats = (int16*)palloc(numPFormats * sizeof(int16));
        for (i = 0; i < numPFormats; i++)
            pformats[i] = pq_getmsgint(input_message, 2);
    }

    /* Get the parameter value count */
    numParams = pq_getmsgint(input_message, 2);

    if (numPFormats > 1 && numPFormats != numParams)
        ereport(ERROR,
            (errcode(ERRCODE_PROTOCOL_VIOLATION),
                errmsg("bind message has %d parameter formats but %d parameters", numPFormats, numParams)));

    /* Get the parameter value */
    if (numParams > 0) {
        int paramno;
        Oid param_collation = GetCollationConnection();
        int param_charset = GetCharsetConnection();

        params = (ParamListInfo)palloc(offsetof(ParamListInfoData, params) + numParams * sizeof(ParamExternData));

        /* we have static list of params, so no hooks needed */
        params->paramFetch = NULL;
        params->paramFetchArg = NULL;
        params->parserSetup = NULL;
        params->parserSetupArg = NULL;
        params->params_need_process = false;
        params->uParamInfo = DEFUALT_INFO;
        params->params_lazy_bind = false;
        params->numParams = numParams;

        for (paramno = 0; paramno < numParams; paramno++) {
            Oid ptype = paramTypes[paramno];
            int32 plength;
            Datum pval = 0;
            bool isNull = false;
            StringInfoData pbuf;
            char csave;
            int16 pformat;

            plength = pq_getmsgint(input_message, 4);
            isNull = (plength == -1);

            if (!isNull) {
                const char* pvalue = pq_getmsgbytes(input_message, plength);

                /*
                 * Rather than copying data around, we just set up a phony
                 * StringInfo pointing to the correct portion of the message
                 * buffer.	We assume we can scribble on the message buffer so
                 * as to maintain the convention that StringInfos have a
                 * trailing null.  This is grotty but is a big win when
                 * dealing with very large parameter strings.
                 */
                pbuf.data = (char*)pvalue;
                pbuf.maxlen = plength + 1;
                pbuf.len = plength;
                pbuf.cursor = 0;

                csave = pbuf.data[plength];
                pbuf.data[plength] = '\0';
            } else {
                pbuf.data = NULL; /* keep compiler quiet */
                csave = 0;
            }

            if (numPFormats > 1) {
                Assert(NULL != pformats);
                pformat = pformats[paramno];
            } else if (numPFormats > 0) {
                Assert(NULL != pformats);
                pformat = pformats[0];
            } else {
                pformat = 0; /* default = text */
            }

            if (pformat == 0) {
                /* text mode */
                Oid typinput;
                Oid typioparam;
                char* pstring = NULL;

                getTypeInputInfo(ptype, &typinput, &typioparam);

                /*
                 * We have to do encoding conversion before calling the
                 * typinput routine.
                 */
                if (isNull) {
                    pstring = NULL;
                } else if (OidIsValid(param_collation) && IsSupportCharsetType(ptype)) {
                    pstring = pg_client_to_any(pbuf.data, plength, param_charset);
                } else {
                    pstring = pg_client_to_server(pbuf.data, plength);
                }

                pval = OidInputFunctionCall(typinput, pstring, typioparam, -1);

                /* Free result of encoding conversion, if any */
                if (pstring != NULL && pstring != pbuf.data) {
                    pfree(pstring);
                }
            } else {
                ereport(
                    ERROR, (errcode(ERRCODE_INVALID_PARAMETER_VALUE), errmsg("unsupported format code: %d", pformat)));
            }

            /* Restore message buffer contents */
            if (!isNull) {
                pbuf.data[plength] = csave;
            }

            params->params[paramno].value = pval;
            params->params[paramno].isnull = isNull;

            /*
             * We mark the params as CONST.  This has no effect if we already
             * did planning, but if we didn't, it licenses the planner to
             * substitute the parameters directly into the one-shot plan we
             * will generate below.
             */
            params->params[paramno].pflags = PARAM_FLAG_CONST;
            params->params[paramno].ptype = ptype;
            params->params[paramno].tabInfo = NULL;
        }
    } else
        params = NULL;

    /* Get the result format codes */
    numRFormats = pq_getmsgint(input_message, 2);
    if (numRFormats != 0) {
        ereport(
            ERROR, (errcode(ERRCODE_INVALID_PARAMETER_VALUE), errmsg("Invalid result format codes: %d.", numRFormats)));
    }

    /* get the fetch size */
    max_rows = pq_getmsgint(input_message, 4);

    /* End of message */
    pq_getmsgend(input_message);

    {
        const char* commandTag = NULL;
        char completionTag[COMPLETION_TAG_BUFSIZE];
        Portal portal;
        DestReceiver* receiver = NULL;

        SetForceXidFromGTM(false);

        commandTag = "SELECT";

        set_ps_display(commandTag, false);

        BeginCommand(commandTag, dest);

        if (IsAbortedTransactionBlockState()) {
            ereport(ERROR,
                (errcode(ERRCODE_IN_FAILED_SQL_TRANSACTION),
                    errmsg("current transaction is aborted, "
                        "commands ignored until end of transaction block, firstChar[%c]",
                        u_sess->proc_cxt.firstChar),
                    errdetail_abort()));
        }

        /* Make sure we are in a transaction command */
        start_xact_command();

        /* If we got a cancel signal in parsing or prior command, quit */
        CHECK_FOR_INTERRUPTS();

        GSCGROUP_ATTACH_TASK();

        MemoryContextSwitchTo(oldcontext);

        portal = CreatePortal("", true, true);

        /* Don't display the portal in pg_cursors */
        portal->visible = false;

        /*
         * We don't have to copy anything into the portal, because everything
         * we are passing here is in t_thrd.mem_cxt.msg_mem_cxt, which will outlive the
         * portal anyway.
         */
        PortalDefineQuery(portal, NULL, "DUMMY", commandTag, lappend(NULL, planstmt), NULL);

        PortalStart(portal, params, 0, u_sess->spq_cxt.snapshot);

        PortalSetResultFormat(portal, numRFormats, rformats);

        /*
         * Now we can create the destination receiver object.
         */
        receiver = CreateDestReceiver(dest);
        if (dest == DestRemote) {
            SetRemoteDestReceiverParams(receiver, portal);
        }
#ifdef USE_SPQ
        if (IS_SPQ_RUNNING && dest == DestRemote)
            SetRemoteDestTupleReceiverParams(receiver);
#endif

        if (max_rows <= 0) {
            max_rows = FETCH_ALL;
        }

        (void)PortalRun(portal, max_rows, true, receiver, receiver, completionTag);

        (*receiver->rDestroy)(receiver);

        PortalDrop(portal, false);

        /* Flush messages left in PqSendBuffer before entering syncQuit. */
        (void)pq_flush();

        /* Set sync point for waiting all stream threads complete. */
        StreamNodeGroup::syncQuit(STREAM_COMPLETE);
        UnRegisterStreamSnapshots();

        /*
         * send the stream instrumentation to the coordinator until all the stream thread quit.
         */
        if (StreamTopConsumerAmI() && u_sess->instr_cxt.global_instr != NULL) {
            u_sess->instr_cxt.global_instr->serializeSend();
            if (u_sess->instr_cxt.global_instr->needTrack()) {
                u_sess->instr_cxt.global_instr->serializeSendTrack();
            }
        }

        if (StreamTopConsumerAmI() && u_sess->instr_cxt.obs_instr != NULL) {
            u_sess->instr_cxt.obs_instr->serializeSend();
        }

        finish_xact_command();
        EndCommand(completionTag, dest);
    }

    finish_xact_command();
}
#endif

#ifdef ENABLE_MULTIPLE_NODES
/* get param oid from paramTypeNames, and save into paramTypes. */
static void GetParamOidFromName(char** paramTypeNames, Oid* paramTypes, int numParams)
{
    // It can't be commit/rollback xact if numParams > 0
    // And if transaction is abort state, we should abort query
    //
    if (IsAbortedTransactionBlockState() && numParams > 0) {
        ereport(ERROR, (errcode(ERRCODE_IN_FAILED_SQL_TRANSACTION), errmsg("current transaction is aborted, "
                    "commands ignored until end of transaction block, firstChar[%c]",
                    u_sess->proc_cxt.firstChar), errdetail_abort()));
    }
    /* we don't expect type mod */
    for (int cnt_param = 0; cnt_param < numParams; cnt_param++) {
        parseTypeString(paramTypeNames[cnt_param], &paramTypes[cnt_param], NULL);
    }
}
#endif

/*
 * exec_parse_message
 *
 * Execute a "Parse" protocol message.
 * If paramTypeNames is specified, paraTypes is filled with corresponding OIDs.
 * The caller is expected to allocate space for the paramTypes.
 */
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif /* PGXC */
#ifdef PGXC
#else
#endif
#ifdef ENABLE_MOT
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef PGXC
#else
#endif
#ifdef ENABLE_MOT
#endif







#ifdef ENABLE_MULTIPLE_NODES
/*
 * exec_get_ddl_params
 *     just get params info from CN
 */
#ifndef ENABLE_UT
static void exec_get_ddl_params(StringInfo input_message)
#else
void exec_get_ddl_params(StringInfo input_message)
#endif
{
    int numPFormats;
    int16* pformats = NULL;
    int numParams;
    int numRFormats;
    int16* rformats = NULL;
    ParamListInfo params = NULL;

    if (unlikely(!((IS_PGXC_COORDINATOR || IS_PGXC_DATANODE) && IsConnFromCoord()))) {
        ereport(ERROR,
            (errcode(ERRCODE_IO_ERROR),
                errmsg("The current node should not receive z messages")));
    }

    if (u_sess->top_transaction_mem_cxt == NULL) {
        ereport(ERROR,
            (errcode(ERRCODE_INVALID_TRANSACTION_STATE),
                errmsg("current transaction is not start")));
    }

    if (u_sess->parser_cxt.ddl_pbe_context == NULL) {
        u_sess->parser_cxt.ddl_pbe_context = AllocSetContextCreate(u_sess->top_mem_cxt,
            "DDLPBEContext",
            ALLOCSET_DEFAULT_MINSIZE,
            ALLOCSET_DEFAULT_INITSIZE,
            ALLOCSET_DEFAULT_MAXSIZE);
    }
    MemoryContext old_context = MemoryContextSwitchTo(u_sess->parser_cxt.ddl_pbe_context);

    /*
     * Get the fixed part of the message, This information is not useful to us, but we still have to process it,
     * because the cursor will change during the processing of the information, otherwise the subsequent information
     * cannot be parsed.
     */
    (void)pq_getmsgstring(input_message);
    (void)pq_getmsgstring(input_message);

    /* Get the parameter format codes */
    numPFormats = pq_getmsgint(input_message, 2);
    if (numPFormats > 0) {
        int i;
        pformats = (int16*)palloc(numPFormats * sizeof(int16));
        for (i = 0; i < numPFormats; i++)
            pformats[i] = pq_getmsgint(input_message, 2);
    }

    /* Get the parameter value count */
    numParams = pq_getmsgint(input_message, 2);
    if (numPFormats > 1 && numPFormats != numParams)
        ereport(ERROR,
            (errcode(ERRCODE_PROTOCOL_VIOLATION),
                errmsg("bind message has %d parameter formats but %d parameters", numPFormats, numParams)));

    if (numParams > 0) {
        int paramno;
        Oid param_collation = GetCollationConnection();
        int param_charset = GetCharsetConnection();
        params = (ParamListInfo)palloc(offsetof(ParamListInfoData, params) + numParams * sizeof(ParamExternData));
        params->paramFetch = NULL;
        params->paramFetchArg = NULL;
        params->parserSetup = NULL;
        params->parserSetupArg = NULL;
        params->params_need_process = false;
        params->uParamInfo = DEFUALT_INFO;
        params->params_lazy_bind = false;
        params->numParams = numParams;

        for (paramno = 0; paramno < numParams; paramno++) {
            Oid ptype = TEXTOID;
            int32 plength;
            Datum pval;
            bool isNull = false;
            StringInfoData pbuf;
            char csave;
            int16 pformat;

            plength = pq_getmsgint(input_message, 4);
            isNull = (plength == -1);

            if (!isNull) {
                const char* pvalue = pq_getmsgbytes(input_message, plength);

                pbuf.data = (char*)pvalue;
                pbuf.maxlen = plength + 1;
                pbuf.len = plength;
                pbuf.cursor = 0;
                csave = pbuf.data[plength];
                pbuf.data[plength] = '\0';
            } else {
                pbuf.data = NULL; /* keep compiler quiet */
                csave = 0;
            }

            if (numPFormats > 1) {
                Assert(NULL != pformats);
                pformat = pformats[paramno];
            } else if (numPFormats > 0) {
                Assert(NULL != pformats);
                pformat = pformats[0];
            } else {
                pformat = 0; /* default = text */
            }
            if (pformat == 0) /* text mode */
            {
                Oid typinput;
                Oid typioparam;
                char* pstring = NULL;

                getTypeInputInfo(ptype, &typinput, &typioparam);

                if (isNull) {
                    pstring = NULL;
                } else if (OidIsValid(param_collation) && IsSupportCharsetType(ptype)) {
                    pstring = pg_client_to_any(pbuf.data, plength, param_charset);
                } else {
                    pstring = pg_client_to_server(pbuf.data, plength);
                }

                pval = OidInputFunctionCall(typinput, pstring, typioparam, -1);

                /* Free result of encoding conversion, if any */
                if (pstring != NULL && pstring != pbuf.data)
                    pfree(pstring);
            } else if (pformat == 1) /* binary mode */
            {
                Oid typreceive;
                Oid typioparam;
                StringInfo bufptr;

                /*
                 * Call the parameter type's binary input converter
                 */
                getTypeBinaryInputInfo(ptype, &typreceive, &typioparam);

                bufptr = isNull ? NULL : &pbuf;
                pval = OidReceiveFunctionCall(typreceive, bufptr, typioparam, -1);

                /* Trouble if it didn't eat the whole buffer */
                if (!isNull && pbuf.cursor != pbuf.len)
                    ereport(ERROR,
                        (errcode(ERRCODE_INVALID_BINARY_REPRESENTATION),
                            errmsg("incorrect binary data format in bind parameter %d", paramno + 1)));
            } else {
                ereport(
                    ERROR, (errcode(ERRCODE_INVALID_PARAMETER_VALUE), errmsg("unsupported format code: %d", pformat)));
                pval = 0; /* keep compiler quiet */
            }

            /* Restore message buffer contents */
            if (!isNull)
                pbuf.data[plength] = csave;

            params->params[paramno].value = pval;
            params->params[paramno].isnull = isNull;

            /*
             * We mark the params as CONST.  This ensures that any custom plan
             * makes full use of the parameter values.
             */
            params->params[paramno].pflags = PARAM_FLAG_CONST;
            params->params[paramno].ptype = ptype;
            params->params[paramno].tabInfo = NULL;
        }
    } else {
        params = NULL;
    }
    u_sess->parser_cxt.param_info = (void*)params;

    MemoryContextSwitchTo(old_context);

    /* Get the result format codes */
    numRFormats = pq_getmsgint(input_message, 2);
    if (numRFormats > 0) {
        int i;
        rformats = (int16*)palloc(numRFormats * sizeof(int16));
        for (i = 0; i < numRFormats; i++)
            rformats[i] = pq_getmsgint(input_message, 2);
    }

    if (pformats != NULL)
        pfree_ext(pformats);
    if (rformats != NULL)
        pfree_ext(rformats);

    pq_getmsgend(input_message);
    pq_putemptymessage('z');
}
#endif

/*
 * exec_bind_message
 *
 * Process a "Bind" message to create a portal from a prepared statement
 */
#ifdef ENABLE_MOT
#endif
#ifndef ENABLE_MULTIPLE_NODES			
#endif
#ifndef ENABLE_MULTIPLE_NODES
#else
#endif
#ifndef ENABLE_MULTIPLE_NODES
#else
#endif               
#ifndef ENABLE_MULTIPLE_NODES
#endif

/*
 * exec_execute_message
 *
 * Process an "Execute" message for a portal
 */
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif

/*
 * check_log_statement
 *		Determine whether command should be logged because of log_statement
 *
 * parsetree_list can be either raw grammar output or a list of planned
 * statements
 */


/*
 * check_log_duration
 *		Determine whether current command's duration should be logged
 *
 * Returns:
 *		0 if no logging is needed
 *		1 if just the duration should be logged
 *		2 if duration and query details should be logged
 *
 * If logging is needed, the duration in msec is formatted into msec_str[],
 * which must be a 32-byte buffer.
 *
 * was_logged should be TRUE if caller already logged query details (this
 * essentially prevents 2 from being returned).
 */


/*
 * errdetail_execute
 *
 * Add an errdetail() line showing the query referenced by an EXECUTE, if any.
 * The argument is the raw parsetree list.
 */


/*
 * get_param_str
 *
 * Forming param string info from ParamListInfo.
 */


/*
 * errdetail_params
 *
 * Add an errdetail() line showing bind-parameter data, if available.
 */


/*
 * errdetail_batch_params
 *
 * Add an errdetail() line showing bind-batch-parameter data, if available.
 */

/*
 * errdetail_abort
 *
 * Add an errdetail() line showing abort reason, if any.
 */


/*
 * errdetail_recovery_conflict
 *
 * Add an errdetail() line showing conflict source.
 */


/*
 * exec_describe_statement_message
 *
 * Process a "Describe" message for a prepared statement
 */
#ifndef ENABLE_UT
#else
#endif
#ifdef ENABLE_MOT
#endif

/*
 * exec_describe_portal_message
 *
 * Process a "Describe" message for a portal
 */


/*
 * Convenience routines for starting/committing a single command.
 */


#ifdef ENABLE_MOT
#endif
#ifdef MEMORY_CONTEXT_CHECKING
#endif
#ifdef SHOW_MEMORY_STATS
#endif

/*
 * Convenience routines for checking whether a statement is one of the
 * ones that we allow in transaction-aborted state.
 */

/* Test a bare parsetree */


/* Test a list that might contain Query nodes or bare parsetrees */


/* Test a list that might contain Query nodes or bare parsetrees */


#ifdef ENABLE_MOT

#endif

/* Release any existing unnamed prepared statement */



/* --------------------------------
 *		signal handler routines used in PostgresMain()
 * --------------------------------
 */

/*
 * quickdie() occurs when signalled SIGQUIT by the postmaster.
 *
 * Some backend has bought the farm,
 * so we need to stop what we're doing and exit.
 */


/*
 * Shutdown signal from postmaster: abort transaction and exit
 * at soonest convenient time
 */


/*
 * Query-cancel signal from postmaster: abort current transaction
 * at soonest convenient time
 */


/*
 * Query-cancel signal from pg_pool_validate: abort current transaction
 * at soonest convenient time
 */
#ifdef ENABLE_MULTIPLE_NODES
#endif

/* signal handler for floating point exception */


/* SIGHUP: set flag to re-read config file at next convenient time */


// HandlePoolerReload
// 	set the flag got_PoolReload, and do pooler reload in the main loop.
//


// HandleMemoryContextDump
// 	call memory dump function directly in aset.cpp to dump all memory info.
//
#ifdef MEMORY_CONTEXT_CHECKING
#endif





/*
 * RecoveryConflictInterrupt: out-of-line portion of recovery conflict
 * handling following receipt of SIGUSR1. Designed to be similar to die()
 * and StatementCancelHandler(). Called only by a normal user backend
 * that begins a transaction during recovery.
 */




/*
 * ProcessInterrupts: out-of-line portion of CHECK_FOR_INTERRUPTS() macro
 *
 * If an interrupt condition is pending, and it's safe to service it,
 * then clear the flag and accept the interrupt.  Called only when
 * InterruptPending is true.
 */
void ProcessInterrupts(void) {}


/*
 * IA64-specific code to fetch the AR.BSP register for stack depth checks.
 *
 * We currently support gcc, icc, and HP-UX inline assembly here.
 */
#if defined(__ia64__) || defined(__ia64)

#if defined(__hpux) && !defined(__GNUC__) && !defined __INTEL_COMPILER
#include <ia64/sys/inline.h>
#define ia64_get_bsp() ((char*)(_Asm_mov_from_ar(_AREG_BSP, _NO_FENCE)))
#else

#ifdef __INTEL_COMPILER
#include <asm/ia64regs.h>
#endif

static __inline__ char* ia64_get_bsp(void)
{
    char* ret = NULL;

#ifndef __INTEL_COMPILER
    /* the ;; is a "stop", seems to be required before fetching BSP */
    __asm__ __volatile__(";;\n"
                         "	mov	%0=ar.bsp	\n"
                         : "=r"(ret));
#else
    ret = (char*)__getReg(_IA64_REG_AR_BSP);
#endif
    return ret;
}
#endif
#endif /* IA64 */

/*
 * set_stack_base: set up reference point for stack depth checking
 *
 * Returns the old reference point, if any.
 */
#if defined(__ia64__) || defined(__ia64)
#else
#endif
#if defined(__ia64__) || defined(__ia64)
#endif

/*
 * restore_stack_base: restore reference point for stack depth checking
 *
 * This can be used after set_stack_base() to restore the old value. This
 * is currently only used in PL/Java. When PL/Java calls a backend function
 * from different thread, the thread's stack is at a different location than
 * the main thread's stack, so it sets the base pointer before the call, and
 * restores it afterwards.
 */
#if defined(__ia64__) || defined(__ia64)
#else
#endif

/*
 * check_stack_depth/stack_is_too_deep: check for excessively deep recursion
 *
 * This should be called someplace in any recursive routine that might possibly
 * recurse deep enough to overflow the stack.  Most Unixen treat stack
 * overflow as an unrecoverable SIGSEGV, so we want to error out ourselves
 * before hitting the hardware limit.
 *
 * check_stack_depth() just throws an error summarily.  stack_is_too_deep()
 * can be used by code that wants to handle the error condition itself.
 */
void check_stack_depth(void)
{
    if (stack_is_too_deep()) {
        ereport(ERROR,
            (errcode(ERRCODE_STATEMENT_TOO_COMPLEX),
                errmsg("stack depth limit exceeded"),
                errhint("Increase the configuration parameter \"max_stack_depth\" (currently %dkB), "
                        "after ensuring the platform's stack depth limit is adequate.",
                    u_sess->attr.attr_common.max_stack_depth)));
    }
}

bool stack_is_too_deep(void)
{
    char stack_top_loc;
    long stack_depth;

    /*
     * Compute distance from reference point to my local variables
     */
    stack_depth = (long)(t_thrd.postgres_cxt.stack_base_ptr - &stack_top_loc);

    /*
     * Take abs value, since stacks grow up on some machines, down on others
     */
    if (stack_depth < 0) {
        stack_depth = -stack_depth;
    }

    /*
     * Trouble?
     *
     * The test on stack_base_ptr prevents us from erroring out if called
     * during process setup or in a non-backend process.  Logically it should
     * be done first, but putting it here avoids wasting cycles during normal
     * cases.
     */
    if (stack_depth > t_thrd.postgres_cxt.max_stack_depth_bytes && t_thrd.postgres_cxt.stack_base_ptr != NULL)
        return true;

        /*
         * On IA64 there is a separate "register" stack that requires its own
         * independent check.  For this, we have to measure the change in the
         * "BSP" pointer from PostgresMain to here.  Logic is just as above,
         * except that we know IA64's register stack grows up.
         *
         * Note we assume that the same max_stack_depth applies to both stacks.
         */
#if defined(__ia64__) || defined(__ia64)
    stack_depth = (long)(ia64_get_bsp() - register_stack_base_ptr);
    if (stack_depth > t_thrd.postgres_cxt.max_stack_depth_bytes && register_stack_base_ptr != NULL)
        return true;
#endif /* IA64 */

    return false;
}

/* GUC check hook for max_stack_depth */


/* GUC assign hook for max_stack_depth */


/*
 * set_debug_options --- apply "-d N" command line option
 *
 * -d is not quite the same as setting log_min_messages because it enables
 * other output options.
 */






/* ----------------------------------------------------------------
 * process_postgres_switches
 *	   Parse command line arguments for PostgresMain
 *
 * This is called twice, once for the "secure" options coming from the
 * postmaster or command line, and once for the "insecure" options coming
 * from the client's startup packet.  The latter have the same syntax but
 * may be restricted in what they can do.
 *
 * argv[0] is ignored in either case (it's assumed to be the program name).
 *
 * ctx is PGC_POSTMASTER for secure options, PGC_BACKEND for insecure options
 * coming from the client, or PGC_SUSET for insecure options coming from
 * a superuser client.
 *
 * If a database name is present in the command line arguments, it's
 * returned into *dbname (this is allowed only if *dbname is initially NULL).
 * ----------------------------------------------------------------
 */
#ifdef PGXC
#endif
#ifdef PGXC
#endif
#ifdef HAVE_INT_OPTERR
#endif
#ifdef PGXC
#ifndef ENABLE_MULTIPLE_NODES
#endif
#endif /* PGXC */
#ifndef ENABLE_MULTIPLE_NODES
#ifndef USE_SPQ
#endif
#endif
#ifdef PGXC
#endif
#ifdef HAVE_INT_OPTRESET
#endif

/* clear key message that may appear in core file for security */


/* read and process the configuration file, just for openGauss backend workers */


/* reload pooler for online business in expansion. */


/* reload pooler if necessary, just pass while in transaction block */


#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
/*
 * @Description: Initialize or refresh global node definition
 *
 * @param[IN] planstmt:  PlannedStmt node which holds the "one time" information needed by the executor
 * @return: void
 */
static void InitGlobalNodeDefinition(PlannedStmt* planstmt)
{
    if (planstmt == NULL)
        return;

    if ((global_node_definition != NULL && global_node_definition->num_nodes == planstmt->num_nodes)
		|| planstmt->nodesDefinition == NULL)
        return;

    AutoMutexLock copyLock(&nodeDefCopyLock);
    copyLock.lock();

    /* first initialization or need update when cluster size changes */
    if (global_node_definition == NULL || global_node_definition->num_nodes != planstmt->num_nodes) {
        MemoryContext oldMemory = MemoryContextSwitchTo(INSTANCE_GET_MEM_CXT_GROUP(MEMORY_CONTEXT_CBB));
        Size nodeDefSize;
        errno_t rc = EOK;

        /* free the old one before refresh */
        if (global_node_definition != NULL) {
            if (global_node_definition->nodesDefinition)
                pfree(global_node_definition->nodesDefinition);
            pfree(global_node_definition);
        }

        global_node_definition = (GlobalNodeDefinition*)palloc(sizeof(GlobalNodeDefinition));
        if ((planstmt->num_nodes > 0) && ((uint)(INT_MAX / planstmt->num_nodes) > sizeof(NodeDefinition))) {
            global_node_definition->num_nodes = planstmt->num_nodes;
            nodeDefSize = mul_size(sizeof(NodeDefinition), (Size)planstmt->num_nodes);
            global_node_definition->nodesDefinition = (NodeDefinition*)palloc(nodeDefSize);
            rc = memcpy_s(global_node_definition->nodesDefinition, nodeDefSize, planstmt->nodesDefinition, nodeDefSize);
            securec_check(rc, "\0", "\0");
        } else {
            copyLock.unLock();
            ereport(ERROR,
                (errcode(ERRCODE_DATA_EXCEPTION),
                    errmsg("invalid number of data nodes when initializing global node definition.")));
        }

        (void)MemoryContextSwitchTo(oldMemory);
    }

    copyLock.unLock();
}
#endif



/*
 * Remove temp namespace.
 */
#ifndef ENABLE_MULTIPLE_NODES
#endif

#if (!defined(ENABLE_MULTIPLE_NODES)) && (!defined(ENABLE_PRIVATEGAUSS))
#define INITIAL_USER_ID 10
/*
 * IMPORTANT:
 * 1. load plugin should call after process is normal, cause heap_create_with_catalog will check it.
 * 2. load plugin should call after mask_password_mem_cxt is created, cause maskPassword is called
 *      when create extension, which need mask_password_mem_cxt.
 */

#endif

/* handle and commit previous stmt metric context in jdbc trace mode. */


/* handle when connection closed*/


/* ----------------------------------------------------------------
 * PostgresMain
 *	   openGauss main loop -- all backends, interactive or otherwise start here
 *
 * argc/argv are the command line arguments to be used.  (When being forked
 * by the postmaster, these are not the original argv array of the process.)
 * dbname is the name of the database to connect to, or NULL if the database
 * name should be extracted from the command line arguments or defaulted.
 * username is the openGauss user name to be used for the session.
 * ----------------------------------------------------------------
 */
#ifdef ENABLE_MULTIPLE_NODES /* PGXC_DATANODE */
#endif
#ifdef DEBUG_UHEAP
#endif
#ifdef ENABLE_MULTIPLE_NODES /* PGXC_COORD */
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifdef EXEC_BACKEND
#else
#endif
#if (!defined(ENABLE_MULTIPLE_NODES)) && (!defined(ENABLE_PRIVATEGAUSS))
#endif
#ifdef ENABLE_MULTIPLE_NODES 
#endif
#ifdef USE_RETRY_STUB
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef USE_RETRY_STUB
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef MEMORY_CONTEXT_CHECKING
#endif
#ifdef USE_SPQ
#endif
#ifdef USE_ASSERT_CHECKING
#endif
#ifdef ENABLE_MULTIPLE_NODES
#else
#endif
#ifdef ENABLE_LLVM_COMPILE
#endif
#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif                    
#ifdef USE_RETRY_STUB
#endif
#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif /* ENABLE_MULTIPLE_NODES */
#ifdef USE_RETRY_STUB
#endif
#ifndef ENABLE_MULTIPLE_NODES
#endif
#ifdef USE_RETRY_STUB
#endif
#ifdef USE_RETRY_STUB
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef USE_RETRY_STUB
#endif
#ifdef USE_RETRY_STUB
#endif
#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
#ifndef USE_SPQ
#endif
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#if defined(ENABLE_MULTIPLE_NODES) || defined(USE_SPQ)
#ifdef USE_SPQ
#else
#endif
#endif
#ifdef ENABLE_MULTIPLE_NODES
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#endif
#ifdef USE_RETRY_STUB
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_MULTIPLE_NODES
#endif
#ifdef ENABLE_HTAP
#endif

/*
 * Obtain platform stack depth limit (in bytes)
 *
 * Return -1 if unknown
 */
#if defined(HAVE_GETRLIMIT) && defined(RLIMIT_STACK)
#else /* no getrlimit */
#if defined(WIN32) || defined(__CYGWIN__)
#else /* not windows ... give up */
#endif
#endif





#if defined(HAVE_GETRUSAGE)
#endif /* HAVE_GETRUSAGE */

/*
 * on_proc_exit handler to log end of session
 */




/* Aduit user logout */
/*
 * Brief		    : audit_processlogout
 * Description	    : audit logout
 */


/* Aduit user logout */
/*
 * Brief		    : audit_processlogout_unified
 * Description	    : audit logout
 */


/*
 * Brief : Check if the initial password of the user has been changed or not.
 *         If not, all the commands from APP should be forbidden except the
 *         "ALTER USER ***".
 *
 * Description : Firstly, we only need to take care of the sqls from client.
 * 				 For synchronization between coordinators, remoteConnType should be
 *               introduced to distinct different status. Secondly, we should not
 *               impact the process of initdb. We make a difference here with
 *         		 'IsUnderPostmaster' status. Thirdly, we only support the gsql
 *               client, the sqls from jdbc && odbc should be passed.
 *
 * Notes : In default, we only deal with the initial user(UserOid == 10).
 */


/*
 * Require user to modify password since password is expired, 
 * all the commands from APP should be forbidden except the
 * "ALTER USER ***".
 */


/*
 * merge_one_relation() will run in a new transaction, so it is necessary to
 * finish the previous transaction before running it, and restart a new transaction
 * after running it;
 */


/* Job worker Process, execute procedure */


/*
 * exec_one_in_batch
 *	main entry of execute one in bind-execute message for not light cn
 *
 * Parameters:
 *	@in psrc: CachedPlanSource
 *	@in params: input params
 *	@in numRFormats: num of result format codes
 *	@in rformats: result format codes
 *	@in send_DP_msg: if send the DP msg
 *	@in dest: command dest
 *	@in completionTag: used in PortalRun and to compute num of processed tuples later.
 *   NULL value means the query is not SELECT/INSERT/UPDATE/DELETE,
 *   and will not count the num of processed tuples.
 *
 * Returns: const char *
 *   If query is not SELECT/INSERT/UPDATE/DELETE, return completionTag, else NULL.
 */
#ifdef ENABLE_MULTIPLE_NODES
#else
#endif
#ifdef ENABLE_MOT
#endif

/*
 * light_preprocess_batchmsg_set
 *	do preprocessing work before constructing batch message for each dn
 *
 * Parameters:
 *	@in psrc: plan
 *	@in params_set: params used to compute dn index
 *	@in params_set_end: params position for computing params size for each dn
 *	@in batch_count: batch count
 *
 *	@out node_idx_set: node index for each bind-execute
 *	@out batch_count_dnset: batch count for each dn
 *	@out params_size_dnset: params size for each dn
 *
 * Returns: void
 */


/*
 * light_construct_batchmsg_set
 *	construct batch messages for light cn for each dn
 *
 * Parameters:
 *	@in input: message from client
 *	@in params_set_end: position index of params in input message
 *	@in node_idx_set: node index set
 *	@in batch_count_dnset: batch count for each dn
 *	@in params_size_dnset: params size for each dn
 *	@in desc_msg: describe message
 *	@in exec_msg: execute message
 *
 * Returns: batch message for each dn
 */


/*
 * light_execute_batchmsg_set
 *	execute batch for light cn for each dn
 *
 * Parameters:
 *	@in scn: Light proxy
 *	@in batch_msg_dnset: batch message for each dn
 *	@in batch_count_dnset: batch count for each dn
 *	@in send_DP_msg: mark if send DP message
 *
 * Returns: process_count
 */


/*
 * exec_batch_bind_execute
 *	main entry of execute batch bind-execute message
 *
 * Parameters:
 *	@in input_message: message from client
 *
 * Returns: void
 */
#ifdef ENABLE_MULTIPLE_NODES
#else
#endif
#ifdef ENABLE_MULTIPLE_NODES
#else
#endif

/* lock function for  g_instance.codegen_IRload_process_count Addition */


/* lock function for  g_instance.codegen_IRload_process_count Subtraction */


/*
 * @Description: get the om online state, expansion/node replace or other.
 * @return : the state of current om online operator.
 */


/* 
 * check whether sql_compatibility is valid
 */
bool checkCompArgs(const char *compFormat)
{
    /* make sure input is not null */
    if (compFormat == NULL) {
        return false;
    }
    if (pg_strncasecmp(compFormat, g_dbCompatArray[DB_CMPT_A].name, sizeof(g_dbCompatArray[DB_CMPT_A].name)) != 0 &&
        pg_strncasecmp(compFormat, g_dbCompatArray[DB_CMPT_B].name, sizeof(g_dbCompatArray[DB_CMPT_B].name)) != 0 &&
        pg_strncasecmp(compFormat, g_dbCompatArray[DB_CMPT_C].name, sizeof(g_dbCompatArray[DB_CMPT_C].name)) != 0 &&
        pg_strncasecmp(compFormat, g_dbCompatArray[DB_CMPT_PG].name, sizeof(g_dbCompatArray[DB_CMPT_PG].name)) != 0 &&
        pg_strncasecmp(compFormat, g_dbCompatArray[DB_CMPT_D].name, sizeof(g_dbCompatArray[DB_CMPT_D].name)) != 0) {
        return false;
    }
    return true;
}



/*--------------------------------------------------------------------
 * Symbols referenced in this file:
 * - SplitIdentifierString
 *--------------------------------------------------------------------
 */

/* -------------------------------------------------------------------------
 *
 * varlena.c
 *	  Functions for the variable-length built-in types.
 *
 * Portions Copyright (c) 1996-2012, PostgreSQL Global Development Group
 * Portions Copyright (c) 1994, Regents of the University of California
 * Portions Copyright (c) 2021, openGauss Contributors
 *
 *
 * IDENTIFICATION
 *	  src/backend/utils/adt/varlena.c
 *
 * -------------------------------------------------------------------------
 */
#include "postgres.h"
#include "knl/knl_variable.h"

#include <limits.h>

#include "access/hash.h"
#include "access/tuptoaster.h"
#include "catalog/pg_collation.h"
#include "catalog/pg_type.h"
#include "common/int.h"
#include "lib/hyperloglog.h"
#include "libpq/md5.h"
#include "libpq/pqformat.h"
#include "miscadmin.h"
#include "parser/scansup.h"
#include "port/pg_bswap.h"
#include "regex/regex.h"
#include "utils/builtins.h"
#include "utils/bytea.h"
#include "utils/lsyscache.h"
#include "utils/memutils.h"
#include "utils/numeric.h"
#include "utils/pg_locale.h"
#include "parser/parser.h"
#include "utils/int8.h"
#include "utils/sortsupport.h"
#include "executor/node/nodeSort.h"
#include "pgxc/groupmgr.h"
#include "openssl/evp.h"
#include "catalog/gs_collation.h"
#include "catalog/pg_collation_fn.h"

#define SUBSTR_WITH_LEN_OFFSET 2
#define SUBSTR_A_CMPT_OFFSET 4
#define JUDGE_INPUT_VALID(X, Y) ((NULL == (X)) || (NULL == (Y)))
#define GET_POSITIVE(X) ((X) > 0 ? (X) : ((-1) * (X)))
static int getResultPostionReverse(text* textStr, text* textStrToSearch, int32 beginIndex, int occurTimes);
static int getResultPostion(text* textStr, text* textStrToSearch, int32 beginIndex, int occurTimes);

typedef struct varlena unknown;
typedef struct varlena VarString;

typedef struct {
    bool use_wchar;  /* T if multibyte encoding */
    char* str1;      /* use these if not use_wchar */
    char* str2;      /* note: these point to original texts */
    pg_wchar* wstr1; /* use these if use_wchar */
    pg_wchar* wstr2; /* note: these are palloc'd */
    int len1;        /* string lengths in logical characters */
    int len2;
    /* Skip table for Boyer-Moore-Horspool search algorithm: */
    int skiptablemask;  /* mask for ANDing with skiptable subscripts */
    int skiptable[256]; /* skip distance for given mismatched char */
} TextPositionState;

typedef struct {
    char* buf1; /* 1st string, or abbreviation original string
                 * buf */
    char* buf2; /* 2nd string, or abbreviation strxfrm() buf */
    int buflen1;
    int buflen2;
    int last_len1;     /* Length of last buf1 string/strxfrm() input */
    int last_len2;     /* Length of last buf2 string/strxfrm() blob */
    int last_returned; /* Last comparison result (cache) */
    bool cache_blob;   /* Does buf2 contain strxfrm() blob, etc? */
    bool collate_c;
    bool bpchar;                /* Sorting pbchar, not varchar/text/bytea? */
    bool estimating;            /* true if estimating cardinality
                                 * refer to NumericSortSupport */
    hyperLogLogState abbr_card; /* Abbreviated key cardinality state */
    /* hyperLogLogState full_card;  Full key cardinality state */
    /* Don't use abbr_card/full_card to evaluate weather abort
     * fast comparation or not, use abbr_card/input_count instead
     * like numeric_sortsupport does.
     */
    int64 input_count; /* number of non-null values seen */
    double prop_card;  /* Required cardinality proportion */
#ifdef HAVE_LOCALE_T
    pg_locale_t locale;
#endif
} VarStringSortSupport;

/*
 * This should be large enough that most strings will fit, but small enough
 * that we feel comfortable putting it on the stack
 */
#define TEXTBUFLEN 1024

#define DatumGetUnknownP(X) ((unknown*)PG_DETOAST_DATUM(X))
#define DatumGetUnknownPCopy(X) ((unknown*)PG_DETOAST_DATUM_COPY(X))
#define PG_GETARG_UNKNOWN_P(n) DatumGetUnknownP(PG_GETARG_DATUM(n))
#define PG_GETARG_UNKNOWN_P_COPY(n) DatumGetUnknownPCopy(PG_GETARG_DATUM(n))
#define PG_RETURN_UNKNOWN_P(x) PG_RETURN_POINTER(x)

static int varstrfastcmp_c(Datum x, Datum y, SortSupport ssup);
static int bpcharfastcmp_c(Datum x, Datum y, SortSupport ssup);
static int varstrfastcmp_builtin(Datum x, Datum y, SortSupport ssup);
static int bpvarstrfastcmp_builtin(Datum x, Datum y, SortSupport ssup);
static int varstrfastcmp_locale(Datum x, Datum y, SortSupport ssup);
static int varstrcmp_abbrev(Datum x, Datum y, SortSupport ssup);
static Datum varstr_abbrev_convert(Datum original, SortSupport ssup);
static bool varstr_abbrev_abort(int memtupcount, SortSupport ssup);
static int text_position(text* t1, text* t2);
static void text_position_setup(text* t1, text* t2, TextPositionState* state);
static int text_position_next(int start_pos, TextPositionState* state);
static void text_position_cleanup(TextPositionState* state);
static text* text_catenate(text* t1, text* t2);
static text* text_overlay(text* t1, text* t2, int sp, int sl);
static void appendStringInfoText(StringInfo str, const text* t);
static bytea* bytea_catenate(bytea* t1, bytea* t2);
static bytea* bytea_substring_orclcompat(Datum str, int S, int L, bool length_not_specified);
static bytea* bytea_overlay(bytea* t1, bytea* t2, int sp, int sl);
static StringInfo makeStringAggState(FunctionCallInfo fcinfo);

static Datum text_to_array_internal(PG_FUNCTION_ARGS);
static text* array_to_text_internal(FunctionCallInfo fcinfo, ArrayType* v, char* fldsep, char* null_string);

static bool text_format_parse_digits(const char** ptr, const char* end_ptr, int* value);
static const char* text_format_parse_format(
    const char* start_ptr, const char* end_ptr, int* argpos, int* widthpos, int* flags, int* width);
static void text_format_string_conversion(
    StringInfo buf, char conversion, FmgrInfo* typOutputInfo, Datum value, bool isNull, int flags, int width);

static void text_format_append_string(StringInfo buf, const char* str, int flags, int width);

// adapt A db's substrb
static text* get_substring_really(Datum str, int32 start, int32 length, bool length_not_specified);

static text* get_result_of_concat(text* result, FunctionCallInfo fcinfo);

/*****************************************************************************
 *	 CONVERSION ROUTINES EXPORTED FOR USE BY C CODE							 *
 *****************************************************************************/

#define TEXTISORANULL(t) ((t) == NULL || VARSIZE_ANY_EXHDR(t) == 0)

/*
 * cstring_to_text
 *
 * Create a text value from a null-terminated C string.
 *
 * The new text value is freshly palloc'd with a full-size VARHDR.
 */


/*
 * cstring_to_text_with_len
 *
 * Same as cstring_to_text except the caller specifies the string length;
 * the string need not be null_terminated.
 */






/*
 * text_to_cstring
 *
 * Create a palloc'd, null-terminated C string from a text value.
 *
 * We support being passed a compressed or toasted text value.
 * This is a bit bogus since such values shouldn't really be referred to as
 * "text *", but it seems useful for robustness.  If we didn't handle that
 * case here, we'd need another routine that did, anyway.
 */




/*
 * text_to_cstring_buffer
 *
 * Copy a text value into a caller-supplied buffer of size dst_len.
 *
 * The text string is truncated if necessary to fit.  The result is
 * guaranteed null-terminated (unless dst_len == 0).
 *
 * We support being passed a compressed or toasted text value.
 * This is a bit bogus since such values shouldn't really be referred to as
 * "text *", but it seems useful for robustness.  If we didn't handle that
 * case here, we'd need another routine that did, anyway.
 */


/*****************************************************************************
 *	 USER I/O ROUTINES														 *
 *****************************************************************************/
#define VAL(CH) ((CH) - '0')
#define DIG(VAL) ((VAL) + '0')

/*
 *		byteain			- converts from printable representation of byte array
 *
 *		Non-printable characters must be passed as '\nnn' (octal) and are
 *		converted to internal form.  '\' must be passed as '\\'.
 *		ereport(ERROR, ...) if bad form.
 *
 *		BUGS:
 *				The input is scanned twice.
 *				The error checking of input is minimal.
 */


/*
 *		byteaout		- converts to printable representation of byte array
 *
 *		In the traditional escaped format, non-printable characters are
 *		printed as '\nnn' (octal) and '\' as '\\'.
 */


// input interface of RAW type


// output interface of RAW type


// Implements interface of rawtohex(text)


// Implements interface of hextoraw(raw)


/*
 *		bytearecv			- converts external binary format to bytea
 */


/*
 *		byteasend			- converts bytea to binary format
 *
 * This is a special case: just copy the input...
 */








/*
 *		textin			- converts "..." to internal representation
 */


/*
 *		textout			- converts internal representation to "..."
 */


/*
 *		textrecv			- converts external binary format to text
 */


/*
 *		textsend			- converts text to binary format
 */


/*
 *		unknownin			- converts "..." to internal representation
 */


/*
 *		unknownout			- converts internal representation to "..."
 */


/*
 *		unknownrecv			- converts external binary format to unknown
 */


/*
 *		unknownsend			- converts unknown to binary format
 */












/* ========== PUBLIC ROUTINES ========== */

/*
 * textlen -
 *	  returns the logical length of a text*
 *	   (which is less than the VARSIZE of the text*)
 */


/*
 * text_length -
 *	Does the real work for textlen()
 *
 *	This is broken out so it can be called directly by other string processing
 *	functions.	Note that the argument is passed as a Datum, to indicate that
 *	it may still be in compressed form.  We can avoid decompressing it at all
 *	in some cases.
 */




/*
 * textoctetlen -
 *	  returns the physical length of a text*
 *	   (which is less than the VARSIZE of the text*)
 */


/*
 * textcat -
 *	  takes two text* and returns a text* that is the concatenation of
 *	  the two.
 *
 * Rewritten by Sapa, sapa@hq.icb.chel.su. 8-Jul-96.
 * Updated by Thomas, Thomas.Lockhart@jpl.nasa.gov 1997-07-10.
 * Allocate space for output in all cases.
 * XXX - thomas 1997-07-10
 */


/*
 * text_catenate
 *	Guts of textcat(), broken out so it can be used by other functions
 *
 * Arguments can be in short-header form, but not compressed or out-of-line
 */
#ifdef ENABLE_MULTIPLE_NODES
#endif

/*
 * charlen_to_bytelen()
 *	Compute the number of bytes occupied by n characters starting at *p
 *
 * It is caller's responsibility that there actually are n characters;
 * the string need not be null-terminated.
 */


/*
 * text_substr()
 * Return a substring starting at the specified position.
 * - thomas 1997-12-31
 *
 * Input:
 *	- string
 *	- starting position (is one-based)
 *	- string length
 *
 * If the starting position is zero or less, then return from the start of the string
 *	adjusting the length to be consistent with the "negative start" per SQL92.
 * If the length is less than zero, return the remaining string.
 *
 * Added multibyte support.
 * - Tatsuo Ishii 1998-4-21
 * Changed behavior if starting position is less than one to conform to SQL92 behavior.
 * Formerly returned the entire string; now returns a portion.
 * - Thomas Lockhart 1998-12-10
 * Now uses faster TOAST-slicing interface
 * - John Gray 2002-02-22
 * Remove "#ifdef MULTIBYTE" and test for encoding_max_length instead. Change
 * behaviors conflicting with SQL92 to meet SQL92 (if E = S + L < S throw
 * error; if E < 1, return '', not entire string). Fixed MB related bug when
 * S > LC and < LC + 4 sometimes garbage characters are returned.
 * - Joe Conway 2002-08-10
 */


/*
 * text_substr_null's function is same to text_substr, only with different return empty values.
 * when return value is a empty values, then return NULL to adapt NULL test.
 */



/*
 * text_substr_no_len -
 *	  Wrapper to avoid opr_sanity failure due to
 *	  one function accepting a different number of args.
 */


/*
 * text_substring -
 *	Does the real work for text_substr() and text_substr_no_len()
 *
 *	This is broken out so it can be called directly by other string processing
 *	functions.	Note that the argument is passed as a Datum, to indicate that
 *	it may still be in compressed/toasted form.  We can avoid detoasting all
 *	of it in some cases.
 *
 *	The result is always a freshly palloc'd datum.
 */




// adapt A db's substr(text str,integer start,integer length)
// when start<0, amend the sartPosition to abs(start) from last char,
// then search backward


// adapt A db's substr(text str,integer start)
// when start<0, amend the sartPosition to abs(start) from last char,
// then search backward


/*
 * textoverlay
 *	Replace specified substring of first string with second
 *
 * The SQL standard defines OVERLAY() in terms of substring and concatenation.
 * This code is a direct implementation of what the standard says.
 */






/*
 * textpos -
 *	  Return the position of the specified substring.
 *	  Implements the SQL92 POSITION() function.
 *	  Ref: A Guide To The SQL Standard, Date & Darwen, 1997
 * - thomas 1997-07-27
 */


/*
 * text_position -
 *	Does the real work for textpos()
 *
 * Inputs:
 *		t1 - string to be searched
 *		t2 - pattern to match within t1
 * Result:
 *		Character index of the first matched char, starting from 1,
 *		or 0 if no match.
 *
 *	This is broken out so it can be called directly by other string processing
 *	functions.
 */


/*
 * text_position_setup, text_position_next, text_position_cleanup -
 *	Component steps of text_position()
 *
 * These are broken out so that a string can be efficiently searched for
 * multiple occurrences of the same pattern.  text_position_next may be
 * called multiple times with increasing values of start_pos, which is
 * the 1-based character position to start the search from.  The "state"
 * variable is normally just a local variable in the caller.
 */







/* varstr_cmp()
 * Comparison function for text strings with given lengths.
 * Includes locale support, but must copy strings to temporary memory
 *	to allow null-termination for inputs to strcoll().
 * Returns an integer less than, equal to, or greater than zero, indicating
 * whether arg1 is less than, equal to, or greater than arg2.
 */
#ifdef HAVE_LOCALE_T
#endif
#ifdef HAVE_LOCALE_T
#endif
#ifdef WIN32
#ifdef HAVE_LOCALE_T
#endif
#endif /* WIN32 */
#ifdef HAVE_LOCALE_T
#endif

/* text_cmp()
 * Internal comparison function for text strings.
 * Returns -1, 0 or 1
 */




/*
 * Comparison functions for text strings.
 *
 * Note: btree indexes need these routines not to leak memory; therefore,
 * be careful to free working copies of toasted datums.  Most places don't
 * need to be so careful.
 */





/*
 * The internal realization of function vtextne.
 */
















/*
 * Generic sortsupport interface for character type's operator classes.
 * Includes locale support, and support for BpChar semantics (i.e. removing
 * trailing spaces before comparison).
 *
 * Relies on the assumption that text, VarChar, BpChar, and bytea all have the
 * same representation.  Callers that always use the C collation (e.g.
 * non-collatable type callers like bytea) may have NUL bytes in their strings;
 * this will not work with any other collation, though.
 */
#ifdef HAVE_LOCALE_T
#endif
#ifdef WIN32
#endif
#ifdef HAVE_LOCALE_T
#endif
#ifdef HAVE_LOCALE_T
#endif

/*
 * sortsupport comparison func (for C locale case)
 */


/*
 * sortsupport comparison func (for C locale case)
 * for characher(n)
 */


/*
 * sortsupport comparison func (for builtin locale case)
 */



/*
 * sortsupport comparison func (for locale case)
 */
#ifdef HAVE_LOCALE_T
#endif

/*
 * Abbreviated key comparison func
 */


/*
 * Conversion routine for sortsupport.  Converts original to abbreviated key
 * representation.  Our encoding strategy is simple -- pack the first 8 bytes
 * of a strxfrm() blob into a Datum (on little-endian machines, the 8 bytes are
 * stored in reverse order), and treat it as an unsigned integer.  When the "C"
 * locale is used, or in case of bytea, just memcpy() from original instead.
 */
#ifdef HAVE_LOCALE_T
#endif
#if SIZEOF_DATUM == 8
#else /* SIZEOF_DATUM != 8 */
#endif

/*
 * Callback for estimating effectiveness of abbreviated key optimization, using
 * heuristic rules.  Returns value indicating if the abbreviation optimization
 * should be aborted, based on its projected effectiveness.
 */
#ifdef TRACE_SORT
#endif
#ifdef TRACE_SORT
#endif
#ifdef TRACE_SORT
#endif





/*
 * The following operators support character-by-character comparison
 * of text datums, to allow building indexes suitable for LIKE clauses.
 * Note that the regular texteq/textne comparison operators are assumed
 * to be compatible with these!
 */













/* -------------------------------------------------------------
 * byteaoctetlen
 *
 * get the number of bytes contained in an instance of type 'bytea'
 * -------------------------------------------------------------
 */


/*
 * byteacat -
 *	  takes two bytea* and returns a bytea* that is the concatenation of
 *	  the two.
 *
 * Cloned from textcat and modified as required.
 */


/*
 * bytea_catenate
 *	Guts of byteacat(), broken out so it can be used by other functions
 *
 * Arguments can be in short-header form, but not compressed or out-of-line
 */
#ifdef ENABLE_MULTIPLE_NODES
#endif

#define PG_STR_GET_BYTEA(str_) DatumGetByteaP(DirectFunctionCall1(byteain, CStringGetDatum(str_)))

/*
 * bytea_substr()
 * Return a substring starting at the specified position.
 * Cloned from text_substr and modified as required.
 *
 * Input:
 *	- string
 *	- starting position (is one-based)
 *	- string length (optional)
 *
 * If the starting position is zero or less, then return from the start of the string
 * adjusting the length to be consistent with the "negative start" per SQL92.
 * If the length is less than zero, an ERROR is thrown. If no third argument
 * (length) is provided, the length to the end of the string is assumed.
 */


/*
 * bytea_substr_no_len -
 *	  Wrapper to avoid opr_sanity failure due to
 *	  one function accepting a different number of args.
 */




// adapt A db's substr(bytea str,integer start,integer length)
// when start<0, amend the sartPosition to abs(start) from last char,
// then search backward


// adapt A db's substr(bytea x,integer y)
// when start<0, amend the sartPosition to abs(start) from last char,
// then search backward


// Does the real work for bytea_substr_orclcompat() and bytea_substr_no_len_orclcompat().
// The result is always a freshly palloc'd datum.
// when length_not_specified==false, the param length is not used,
// usually called by text_substr_no_len_orclcompat().
// when length_not_specified==true, the param length is not used,
// sually called by text_substr_orclcompat()


/*
 * byteaoverlay
 *	Replace specified substring of first string with second
 *
 * The SQL standard defines OVERLAY() in terms of substring and concatenation.
 * This code is a direct implementation of what the standard says.
 */






/*
 * byteapos -
 *	  Return the position of the specified substring.
 *	  Implements the SQL92 POSITION() function.
 * Cloned from textpos and modified as required.
 */


/* -------------------------------------------------------------
 * byteaGetByte
 *
 * this routine treats "bytea" as an array of bytes.
 * It returns the Nth byte (a number between 0 and 255).
 * -------------------------------------------------------------
 */


/* -------------------------------------------------------------
 * byteaGetBit
 *
 * This routine treats a "bytea" type like an array of bits.
 * It returns the value of the Nth bit (0 or 1).
 *
 * -------------------------------------------------------------
 */


/* -------------------------------------------------------------
 * byteaSetByte
 *
 * Given an instance of type 'bytea' creates a new one with
 * the Nth byte set to the given value.
 *
 * -------------------------------------------------------------
 */


/* -------------------------------------------------------------
 * byteaSetBit
 *
 * Given an instance of type 'bytea' creates a new one with
 * the Nth bit set to the given value.
 *
 * -------------------------------------------------------------
 */


/* text_name()
 * Converts a text type to a Name type.
 */


/* name_text()
 * Converts a Name type to a text type.
 */


/*
 * textToQualifiedNameList - convert a text object to list of names
 *
 * This implements the input parsing needed by nextval() and other
 * functions that take a text parameter representing a qualified name.
 * We split the name at dots, downcase if not double-quoted, and
 * truncate names if they're too long.
 */


/*
 * SplitIdentifierString --- parse a string containing identifiers
 *
 * This is the guts of textToQualifiedNameList, and is exported for use in
 * other situations such as parsing GUC variables.	In the GUC case, it's
 * important to avoid memory leaks, so the API is designed to minimize the
 * amount of stuff that needs to be allocated and freed.
 *
 * Inputs:
 *	rawstring: the input string; must be overwritable!	On return, it's
 *			   been modified to contain the separated identifiers.
 *	separator: the separator punctuation expected between identifiers
 *			   (typically '.' or ',').	Whitespace may also appear around
 *			   identifiers.
 * Outputs:
 *	namelist: filled with a palloc'd list of pointers to identifiers within
 *			  rawstring.  Caller should list_free_ext() this even on error return.
 *
 * Returns TRUE if okay, FALSE if there is a syntax error in the string.
 *
 * Note that an empty string is considered okay here, though not in
 * textToQualifiedNameList.
 */
bool SplitIdentifierString(char* rawstring, char separator, List** namelist, bool downCase, bool truncateToolong)
{
    char* nextp = rawstring;
    bool done = false;
    errno_t ss_rc = 0;

    *namelist = NIL;

    while (isspace((unsigned char)*nextp))
        nextp++; /* skip leading whitespace */

    if (*nextp == '\0')
        return true; /* allow empty string */

    /* At the top of the loop, we are at start of a new identifier. */
    char* curname = NULL;
    char* endp = NULL;
    char* downname = NULL;
    do {
        if (*nextp == '\"') {
            /* Quoted name --- collapse quote-quote pairs, no downcasing */
            curname = nextp + 1;
            for (;;) {
                endp = strchr(nextp + 1, '\"');
                if (endp == NULL)
                    return false; /* mismatched quotes */
                if (endp[1] != '\"')
                    break; /* found end of quoted name */
                /* Collapse adjacent quotes into one quote, and look again */
                if (strlen(endp) > 0) {
                    ss_rc = memmove_s(endp, strlen(endp), endp + 1, strlen(endp));
                    securec_check(ss_rc, "\0", "\0");
                }
                nextp = endp;
            }
            /* endp now points at the terminating quote */
            nextp = endp + 1;
        } else {
            /* Unquoted name --- extends to separator or whitespace */
            int len;

            curname = nextp;
            while (*nextp && *nextp != separator && !isspace((unsigned char)*nextp))
                nextp++;
            endp = nextp;
            if (curname == nextp)
                return false; /* empty unquoted name not allowed */

            /*
             * Downcase the identifier, using same code as main lexer does.
             *
             * XXX because we want to overwrite the input in-place, we cannot
             * support a downcasing transformation that increases the string
             * length.	This is not a problem given the current implementation
             * of downcase_truncate_identifier, but we'll probably have to do
             * something about this someday.
             */
            len = endp - curname;

            /*
             * If downCase is false need not to convert to lowercase when this function is called by
             * get_typeoid_with_namespace, because this curname is come from datanode's system table, if we will it
             * alter to lower that will this schema or columnName can not be found.
             */
            if (downCase) {
                downname = downcase_truncate_identifier(curname, len, false);

                Assert(strlen(downname) <= (unsigned int)(len));
                strncpy(curname, downname, len);
                pfree_ext(downname);
            }
        }

        while (isspace((unsigned char)*nextp))
            nextp++; /* skip trailing whitespace */

        if (*nextp == separator) {
            nextp++;
            while (isspace((unsigned char)*nextp))
                nextp++; /* skip leading whitespace for next */
                         /* we expect another name, so done remains false */
        } else if (*nextp == '\0')
            done = true;
        else
            return false; /* invalid syntax */

        /* Now safe to overwrite separator with a null */
        *endp = '\0';
        if (truncateToolong == true) {
            /* Truncate name if it's overlength */
            truncate_identifier(curname, strlen(curname), false);
        }
        /*
         * Finished isolating current name --- add it to list
         */
        *namelist = lappend(*namelist, curname);

        /* Loop back if we didn't reach end of string */
    } while (!done);

    return true;
}



/*****************************************************************************
 *	Comparison Functions used for bytea
 *
 * Note: btree indexes need these routines not to leak memory; therefore,
 * be careful to free working copies of toasted datums.  Most places don't
 * need to be so careful.
 *****************************************************************************/

































/*
 * appendStringInfoText
 *
 * Append a text to str.
 * Like appendStringInfoString(str, text_to_cstring(t)) but faster.
 */


/*
 * replace_text_with_two_args
 * replace all occurrences of 'old_sub_str' in 'orig_str'
 * with '' to form 'new_str'
 *
 * the effect is equivalent to
 *
 * delete all occurrences of 'old_sub_str' in 'orig_str'
 * to form 'new_str'
 *
 * returns 'orig_str' if 'old_sub_str' == '' or 'orig_str' == ''
 * otherwise returns 'new_str'
 */


/*
 * replace_text
 * replace all occurrences of 'old_sub_str' in 'orig_str'
 * with 'new_sub_str' to form 'new_str'
 *
 * returns 'orig_str' if 'old_sub_str' == '' or 'orig_str' == ''
 * otherwise returns 'new_str'
 */


/*
 * check_replace_text_has_escape_char
 *
 * check whether replace_text contains escape char.
 */


/*
 * appendStringInfoRegexpSubstr
 *
 * Append replace_text to str, substituting regexp back references for
 * \n escapes.	start_ptr is the start of the match in the source string,
 * at logical character position data_pos.
 */


#define REGEXP_REPLACE_BACKREF_CNT 10

/*
 * replace_text_regexp
 *
 * replace text that matches to regexp in src_text to replace_text.
 *
 * Note: to avoid having to include regex.h in builtins.h, we declare
 * the regexp argument as void *, but really it's regex_t *.
 * occur : the n-th matched occurrence, start from 1.
 */


/*
 * split_text
 * parse input string
 * return ord item (1 based)
 * based on provided field separator
 */


/*
 * Convenience function to return true when two text params are equal.
 */


/*
 * text_to_array
 * parse input string and return text array of elements,
 * based on provided field separator
 */


/*
 * text_to_array_null
 * parse input string and return text array of elements,
 * based on provided field separator and null string
 *
 * This is a separate entry point only to prevent the regression tests from
 * complaining about different argument sets for the same internal function.
 */


/*
 * common code for text_to_array and text_to_array_null functions
 *
 * These are not strict so we have to test for null inputs explicitly.
 */


/*
 * array_to_text
 * concatenate Cstring representation of input array elements
 * using provided field separator
 */


/*
 * array_to_text_null
 * concatenate Cstring representation of input array elements
 * using provided field separator and null string
 *
 * This version is not strict so we have to test for null inputs explicitly.
 */


/*
 * common code for array_to_text and array_to_text_null functions
 */


#define HEXBASE 16
/*
 * Convert a int32 to a string containing a base 16 (hex) representation of
 * the number.
 */


/*
 * Convert a int64 to a string containing a base 16 (hex) representation of
 * the number.
 */


/*
 * Create an md5 hash of a text string and return it as hex
 *
 * md5 produces a 16 byte (128 bit) hash; double it for hex
 */
#define MD5_HASH_LEN 32



/*
 * Create an md5 hash of a bytea field and return it as a hex string:
 * 16-byte md5 digest is represented in 32 hex characters.
 */


/*
 * Create an sha/sha1/sha2 hash of a text string and return it as hex
 */

/* SHA-1 Various Length Definitions */
#define SHA1_ALG_TYPE 160
#define SHA1_DIGEST_LENGTH 20

/* SHA-224 / SHA-256 /SHA-384 / SHA-512 Various Length Definitions */
#define SHA224_ALG_TYPE 224
#define SHA224_DIGEST_LENGTH 28
#define SHA256_ALG_TYPE 256
#define SHA256_DIGEST_LENGTH 32
#define SHA384_ALG_TYPE 384
#define SHA384_DIGEST_LENGTH 48
#define SHA512_ALG_TYPE 512
#define SHA512_DIGEST_LENGTH 64

#define SHA_ERROR_LENGTH (GS_UINT32)(-1)



/* Converts binary character streams to hexadecimal return */


/* get_hash_digest_length: choose the unsigned char sha length by secure hash algorithm */


/* get_evp_md: choose EVP_MD value by secure hash algorithm */


/* function to generate sha /sha1 /sha2 */


/*
 * Create an sha1 hash of a bytea field and return it as a hex string:
 * 20-byte sha1 digest is represented in 40 hex characters.
 */


/*
 * the calculation of sha and sha1 is the same.
 */



/*
 * Create an sha2 hash of a bytea field and return it as a hex string:
 * 28-byte sha224 digest is represented in 56 hex characters.
 * 32-byte sha256 or sha0 digest is represented in 64 hex characters.
 * 48-byte sha384 digest is represented in 96s hex characters.
 * 64-byte sha512 digest is represented in 96s hex characters.
 */


/*
 * Return the size of a datum, possibly compressed
 *
 * Works on any data type
 */


/*
 * @Description: This function is used to calculate the size of a datum
 *
 * @IN PG_FUNCTION_ARGS: any data type
 * @return: the byte size of the data
 */


/*
 * string_agg - Concatenates values and returns string.
 *
 * Syntax: string_agg(value text, delimiter text) RETURNS text
 *
 * Note: Any NULL values are ignored. The first-call delimiter isn't
 * actually used at all, and on subsequent calls the delimiter precedes
 * the associated value.
 */

/* subroutine to initialize state */






/*
 * checksumtext_agg_transfn - sum the oldsumofhashvalue and the value of text input and returns numeric.
 *
 * Syntax: checksumtext_agg_transfn(numeric, text) RETURNS numeric
 *
 */


















































/*
 * Implementation of both concat() and concat_ws().
 *
 * sepstr/seplen describe the separator.  argidx is the first argument
 * to concatenate (counting from zero).
 */




/*
 * Concatenate all arguments with separator. NULL arguments are ignored.
 */

/*
 * Concatenate all arguments with separator. NULL arguments are ignored.
 */


/*
 * Concatenate all arguments. NULL arguments are ignored.
 */


/*
 * Concatenate all but first argument value with separators. The first
 * parameter is used as the separator. NULL arguments are ignored.
 */


/*
 * Return first n characters in the string. When n is negative,
 * return all but last |n| characters.
 */

/*
 * Return last n characters in the string. When n is negative,
 * return all but first |n| characters.
 */


/*
 * Return reversed string
 */


/*
 * Support macros for text_format()
 */
#define TEXT_FORMAT_FLAG_MINUS 0x0001 /* is minus flag present? */

#define ADVANCE_PARSE_POINTER(ptr, end_ptr)                                                                          \
    do {                                                                                                             \
        if (++(ptr) >= (end_ptr))                                                                                    \
            ereport(ERROR, (errcode(ERRCODE_INVALID_PARAMETER_VALUE), errmsg("unterminated conversion specifier"))); \
    } while (0)

/*
 * Returns a formated string
 */


/*
 * Parse contiguous digits as a decimal number.
 *
 * Returns true if some digits could be parsed.
 * The value is returned into *value, and *ptr is advanced to the next
 * character to be parsed.
 *
 * Note parsing invariant: at least one character is known available before
 * string end (end_ptr) at entry, and this is still true at exit.
 */


/*
 * Parse a format specifier (generally following the SUS printf spec).
 *
 * We have already advanced over the initial '%', and we are looking for
 * [argpos][flags][width]type (but the type character is not consumed here).
 *
 * Inputs are start_ptr (the position after '%') and end_ptr (string end + 1).
 * Output parameters:
 *	argpos: argument position for value to be printed.  -1 means unspecified.
 *	widthpos: argument position for width.  Zero means the argument position
 *			was unspecified (ie, take the next arg) and -1 means no width
 *			argument (width was omitted or specified as a constant).
 *	flags: bitmask of flags.
 *	width: directly-specified width value.  Zero means the width was omitted
 *			(note it's not necessary to distinguish this case from an explicit
 *			zero width value).
 *
 * The function result is the next character position to be parsed, ie, the
 * location where the type character is/should be.
 *
 * Note parsing invariant: at least one character is known available before
 * string end (end_ptr) at entry, and this is still true at exit.
 */


/*
 * Format a %s, %I, or %L conversion
 */


/*
 * Append str to buf, padding as directed by flags/width
 */


/*
 * text_format_nv - nonvariadic wrapper for text_format function.
 *
 * note: this wrapper is necessary to pass the sanity check in opr_sanity,
 * which checks that all built-in functions that share the implementing C
 * function take the same number of arguments.
 */


// scan the source string forward


// scan the source string backward


// start from beginIndex, find the first position of textStrToSearch in textStr


// search from beginIndex,return the position of textStrToSearch when finding occurTimes in textStr


// instr(varchar string, varchar string_to_search, integer beg_index)
// start from position beg_index, get the index of the first match of string_to_search in string
// character sets considered, different character sets, different characters in the number of bytes
// for example,a Chinese character stored in three bytes



// adapt A db's empty_blob ()


// adapt A db's substrb(text str,integer start,integer length)


// adapt A db's substr(text str,integer start)






/*
 * This function does the real work for substrb_with_lenth() and substrb_without_lenth().
 */









